# TerraScan – Land Suitability Assessment Engine

Evaluate any coordinate on Earth for **construction suitability** and **human habitability** using real-time terrain, climate, soil, seismic, and infrastructure data.

---

## Quick Start

```bash
# 1. Create virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Mac/Linux

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the server
python -m app.main
```

Open **http://localhost:8000** → click anywhere on the map.

---

## Project Phases

| Phase | What | Where | Status |
|-------|------|-------|--------|
| 0 | Setup (FastAPI, venv) | `app/main.py` | ✅ |
| 1 | Terrain / slope scoring | `app/data_fetch.py`, `app/scoring.py` | ✅ |
| 2 | Climate / habitability | `app/data_fetch.py`, `app/scoring.py` | ✅ |
| 3 | Combined API endpoint | `app/main.py` → `/api/score` | ✅ |
| 4 | Hazards (soil, seismic, flood, access) | `app/data_fetch.py`, `app/scoring.py` | ✅ |
| 5 | Prithvi imagery (Colab) | `colab/phase5_prithvi.py` | ✅ (script ready) |
| 6 | Imagery integration | `app/imagery.py`, `app/scoring.py` | ✅ |
| 7 | Frontend (Leaflet map) | `static/` | ✅ |
| 8 | Learned model (optional) | Future work | 📝 |

---

## API

### `GET /api/score?lat=28.61&lon=77.21`

Returns:
```json
{
  "construction_score": 72.3,
  "habitability_score": 58.1,
  "overall_score": 65.9,
  "factors": {
    "slope":     { "score": 95, "rating": "Excellent" },
    "elevation": { "score": 100, "rating": "Excellent" },
    "climate":   { "score": 52, "rating": "Moderate" },
    "soil":      { "score": 65, "rating": "Good" },
    "seismic":   { "score": 40, "rating": "Fair" },
    "flood":     { "score": 85, "rating": "Excellent" },
    "access":    { "score": 95, "rating": "Excellent" }
  },
  "warnings": ["Seismic zone — 25 M4+ quakes..."],
  "hard_constraints": []
}
```

---

## Testing

```bash
python -m tests.test_known_places
```

Tests three Indian cities: Delhi (flat), Shimla (mountain), Mumbai (coastal).

---

## Phase 5: Prithvi on Colab

1. Open [Google Colab](https://colab.research.google.com)
2. Set runtime → **GPU → T4**
3. Copy the contents of `colab/phase5_prithvi.py` into a cell
4. Uncomment and run the pip install line at the top
5. Run the cell — it downloads Sentinel-2 imagery and extracts features
6. Download the `prithvi_features/` folder
7. Place it in your project root next to `app/`
8. Restart the FastAPI server — it auto-detects the features

---

## Architecture

```
┌─────────────┐     ┌──────────────────────────────────────────┐
│   Frontend   │────▶│  FastAPI  /api/score?lat=..&lon=..       │
│  Leaflet map │◀────│                                          │
└─────────────┘     │  ┌─────────────────────────────────────┐ │
                    │  │ ThreadPoolExecutor (5 workers)       │ │
                    │  │  ├─ Open-Meteo Elevation → slope     │ │
                    │  │  ├─ Open-Meteo Archive → climate     │ │
                    │  │  ├─ ISRIC SoilGrids → soil           │ │
                    │  │  ├─ USGS Earthquake → seismic        │ │
                    │  │  └─ OSM Overpass → infrastructure    │ │
                    │  └─────────────────────────────────────┘ │
                    │  ┌─────────────────────────────────────┐ │
                    │  │ Scoring Engine                       │ │
                    │  │  Piecewise-linear interpolation      │ │
                    │  │  Weighted sum → scores               │ │
                    │  │  Hard constraints + warnings         │ │
                    │  └─────────────────────────────────────┘ │
                    │  ┌─────────────────────────────────────┐ │
                    │  │ Prithvi Features (optional)          │ │
                    │  │  Loaded from prithvi_features/*.json │ │
                    │  └─────────────────────────────────────┘ │
                    └──────────────────────────────────────────┘
```

---

## Data Sources (all free, no API keys)

| Source | Data | API |
|--------|------|-----|
| Open-Meteo | Elevation, climate | open-meteo.com |
| ISRIC SoilGrids | Soil composition | rest.isric.org |
| USGS | Earthquake catalog | earthquake.usgs.gov |
| OpenStreetMap | Roads, water | overpass-api.de |
| Planetary Computer | Sentinel-2 imagery | planetarycomputer.microsoft.com |
| Hugging Face | Prithvi-100M model | huggingface.co/ibm-nasa-geospatial |

## NASA HLS V2.0 and Prithvi-EO-2.0

The HLS pipeline is optional. Run the commands from this project directory. Use a supported Python environment (Python 3.12 is a practical choice for the geospatial and PyTorch wheels):

```powershell
python -m pip install -r requirements.txt -r requirements-hls.txt
python -c "import earthaccess, rasterio, geopandas, numpy, torch, terratorch"
```

### District boundaries and Earthdata

Download district polygons from the [National Water Data Portal district dataset](https://nwdp.nwic.gov.in/dataset/district-boundary) or the [NIC administrative district layer](https://webgis1.nic.in/nicstreet/rest/services/admin2024/MapServer/10). Filter the layer by the Uttar Pradesh state attribute before exporting it. Save the result as `up-districts.geojson` with a valid CRS and confirm that its 75 distinct named districts match the [Local Government Directory](https://lgdirectory.gov.in/). Record the source and boundary vintage alongside the input. The examples assume a district name field called `dtname`; substitute the real field name when needed. The pipeline checks the district count, geometries and approximate geographic extent and saves its canonical boundary snapshot with the outputs.

Use a [NASA Earthdata Login](https://urs.earthdata.nasa.gov/) account with LP DAAC access. Run with `--interactive` in a private terminal to enter credentials through earthaccess without writing them to disk. For unattended runs use a securely injected `EARTHDATA_TOKEN` or the account's existing netrc configuration. Keep credentials outside the project and out of shell history and logs.

### Pilot, then regional processing

Choose dates for the study. The following are example windows, and the regional window should reflect the intended season and coverage.

```powershell
python hls_dataset.py pilot --boundaries up-districts.geojson --name-field dtname --start 2025-02-01 --end 2025-02-28 --plan
python hls_dataset.py pilot --boundaries up-districts.geojson --name-field dtname --start 2025-02-01 --end 2025-02-28 --interactive
python hls_dataset.py regional --boundaries up-districts.geojson --name-field dtname --start 2025-02-01 --end 2025-02-28 --plan
python hls_dataset.py regional --boundaries up-districts.geojson --name-field dtname --start 2025-02-01 --end 2025-02-28 --interactive
```

The pilot selects one acquisition per sensor for Lucknow. Check its `coverage.json` and inspect a patch's imagery, mask and location before launching the regional download. If the pilot has inadequate clear pixels, use a different date interval or target district with a new `--output` directory. Use the same output root for both stages. Regional downloading requires a successful pilot for both sensors. Discovery queries NASA's Common Metadata Repository for the selected extent and dates. The regional stage requests all matching L30 and S30 tiles and verifies that each of the 75 districts has accepted pixels from each product. `coverage.json` reports missing districts and failed granules.

A cold two-granule pilot reserves about **1.48 GiB**. The regional estimate is date-dependent. A cold run reserves about **0.74 GiB per granule** including headroom. The plan counts up to seven assets at 32 MB each, up to 289 uncompressed output chips per granule, then adds 15% headroom. Actual compressed files and district clipping usually take less. `--plan` prints the live granule count, uncached assets, estimated storage and available space before any imagery transfer. The same check runs before downloading. Allow separate space for packages and any model weights.

Restart with identical options to reuse the saved plan, cached TIFFs, partial HTTP transfers, completed granules and indexed patches. If a server ignores a range request the affected asset restarts from byte zero. A changed analysis configuration requires a new output root. The `TERRASCAN_HLS_DIR` environment variable tells the API where to find an alternate output root.

### Preprocessing and provenance

| Prithvi input | HLSL30 | HLSS30 |
| --- | --- | --- |
| Blue | B02 | B02 |
| Green | B03 | B03 |
| Red | B04 | B04 |
| Narrow NIR | B05 | B8A |
| SWIR 1 | B06 | B11 |
| SWIR 2 | B07 | B12 |

Each granule uses the native 30 m Fmask grid. Any spectral asset whose grid differs is warped to it using nearest-neighbor resampling. District polygons are projected into the same grid. Cloud, cloud adjacency, cloud shadow, snow/ice, QA fill and reflectance fill are excluded. Water stays in the reflectance sample and has a separate QA mask. Reflectance uses the HLS scale 0.0001 and offset 0. Z-score normalization uses the checkpoint's per-band means and standard deviations in the same reflectance units. Invalid and padded pixels are zero in normalized space and identified explicitly in band 7.

The compressed GeoTIFFs store six model inputs in bands 1–6, the valid-pixel mask in band 7, and the QA water mask in band 8. They preserve the CRS, affine transform, scene ID, acquisition time, center coordinates, valid fraction and contributing districts. Patch tags also include median NDVI and the water fraction among valid district pixels. Edge patches are padded to 224 × 224. The clear fraction is measured inside the rasterized district footprint, excluding padding from the denominator. For temporal model input, `prithvi_inputs.load_prithvi_sequence` requires four distinct acquisition dates with identical grids. It returns a normalized `[1, 6, 4, 224, 224]` tensor with temporal coordinates, location coordinates and validity masks. The pilot verifies individual acquisition chips.

### TerraScan scoring and limitations

The existing point-level Prithvi JSON takes precedence. When it is unavailable, the imagery factor can use a completed HLS dataset. The API checks the newest valid intersecting patch with a valid pixel at the requested coordinate. It applies the current mostly-water rule when that pixel is flagged as water and over half of the clear district pixels in the patch are flagged as water. Without this evidence, the optional imagery factor is omitted and the existing factors retain their relative weights.

Fmask water is a dated surface observation. Cloud, seasonal changes, shadows, narrow rivers, mixed pixels and differing observation dates limit its use for land assessment. NDVI is descriptive and currently has no score weight. The Prithvi base checkpoint supplies representations and requires a task-specific trained head and local validation for land-cover or hazard predictions. This pipeline supplies its inputs and uses Fmask for scoring. Regional coverage indicates at least some accepted pixels in each district for each sensor. Inspect clear-pixel fractions and acquisition dates before interpreting it as spatial or temporal completeness.

### Sources and optional benchmarks

- [NASA HLS project and access](https://hls.gsfc.nasa.gov/data-access-and-tools/) and [HLS V2.0 user guide](https://lpdaac.usgs.gov/documents/1698/HLS_User_Guide_V2.pdf)
- [NASA–IBM Prithvi-EO-2.0 source](https://github.com/NASA-IMPACT/Prithvi-EO-2.0) and [300M-TL checkpoint and configuration](https://huggingface.co/ibm-nasa-geospatial/Prithvi-EO-2.0-300M-TL/blob/main/config.json)
- [Sen1Floods11](https://github.com/cloudtostreet/Sen1Floods11) for flood segmentation benchmarks with Sentinel-1 radar and task labels
- [HLS Burn Scars](https://huggingface.co/datasets/ibm-nasa-geospatial/hls_burn_scars/resolve/main/hls_burn_scars.tar.gz) for burned-area segmentation
- [Multi-Temporal Crop Classification training chips](https://huggingface.co/datasets/ibm-nasa-geospatial/multi-temporal-crop-classification/resolve/main/training_chips.tgz) for crop mapping benchmarks

The optional benchmark datasets have their own label definitions and geographic domains. The downloader acquires HLS imagery for Uttar Pradesh.
