/* ═══════════════════════════════════════════════════════════════
   TerraScan – Frontend Logic
   Map interaction, API calls, result rendering, and calamity tab
   ═══════════════════════════════════════════════════════════════ */

// ── Config ────────────────────────────────────────────────────
const API_BASE = window.location.origin;
const CIRCUMFERENCE = 2 * Math.PI * 52; // SVG circle r=52
const CIRCUMFERENCE_HAZARD = 2 * Math.PI * 60; // SVG circle r=60

// ── DOM refs ──────────────────────────────────────────────────
const coordDisplay    = document.getElementById("coord-display");
const inputLat        = document.getElementById("input-lat");
const inputLon        = document.getElementById("input-lon");
const btnSearch       = document.getElementById("btn-search");
const btnClose        = document.getElementById("btn-close");
const resultsPanel    = document.getElementById("results-panel");
const loadingOverlay  = document.getElementById("loading-overlay");
const resultLocation  = document.getElementById("result-location");
const factorsList     = document.getElementById("factors-list");
const detailsSection  = document.getElementById("details-section");
const warningsSection = document.getElementById("warnings-section");
const warningsList    = document.getElementById("warnings-list");
const constraintsSection = document.getElementById("constraints-section");
const constraintsList = document.getElementById("constraints-list");
const sourcesList     = document.getElementById("sources-list");

// Verdict DOM refs
const verdictCard     = document.getElementById("verdict-card");
const verdictBadge    = document.getElementById("verdict-badge");
const verdictTitle    = document.getElementById("verdict-title");
const verdictSummary  = document.getElementById("verdict-summary");
const verdictRecsList = document.getElementById("verdict-recs-list");

// Calamity DOM refs
const calamityCards     = document.getElementById("calamity-cards");
const calamityLoading   = document.getElementById("calamity-loading");
const hazardSummaryText = document.getElementById("hazard-summary-text");
const hazardLevel       = document.getElementById("hazard-level");
const highRiskCount     = document.getElementById("high-risk-count");
const moderateRiskCount = document.getElementById("moderate-risk-count");
const pinpointOutlook = document.getElementById("pinpoint-outlook");
const pinpointOutlookLabel = document.getElementById("pinpoint-outlook-label");
const pinpointOutlookMessage = document.getElementById("pinpoint-outlook-message");
const pinpointOutlookDetail = document.getElementById("pinpoint-outlook-detail");

// History DOM refs
const historyLoading       = document.getElementById("history-loading");
const historySummary       = document.getElementById("history-summary");
const historyStatRow       = document.getElementById("history-stat-row");
const historySources       = document.getElementById("history-sources");
const historyTypeSection   = document.getElementById("history-type-section");
const historyTypeBars      = document.getElementById("history-type-bars");
const historyDecadeSection = document.getElementById("history-decade-section");
const historyDecadeBars    = document.getElementById("history-decade-bars");
const historyTimelineSection = document.getElementById("history-timeline-section");
const historyFilterRow     = document.getElementById("history-filter-row");
const historyTimeline      = document.getElementById("history-timeline");
const historyEmpty         = document.getElementById("history-empty");

// Tab navigation
const tabBtns = document.querySelectorAll(".tab-btn");
const tabContents = document.querySelectorAll(".tab-content");

// ── Map setup ─────────────────────────────────────────────────
const map = L.map("map", {
    center: [22.5, 78.5],  // India centre
    zoom: 5,
    zoomControl: true,
    attributionControl: true,
});

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: '&copy; <a href="https://osm.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19,
}).addTo(map);

let currentMarker = null;
let lastAnalysedLat = null;
let lastAnalysedLon = null;
let _historyData = null;      // cached history response
let _historyActiveFilter = "all"; // current type filter

// ── Tab switching ─────────────────────────────────────────────
tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        const target = btn.dataset.tab;

        tabBtns.forEach(b => b.classList.remove("active"));
        tabContents.forEach(tc => tc.classList.remove("active"));

        btn.classList.add("active");
        document.getElementById(target).classList.add("active");

        // Fetch calamity data on first switch if not loaded
        if (target === "tab-calamity" && lastAnalysedLat !== null && !calamityCards.dataset.loaded) {
            fetchCalamityData(lastAnalysedLat, lastAnalysedLon);
        }
        // Fetch history data on first switch if not loaded
        if (target === "tab-history" && lastAnalysedLat !== null && !historyTimeline.dataset.loaded) {
            fetchHistoryData(lastAnalysedLat, lastAnalysedLon);
        }
    });
});

// ── Map click handler ─────────────────────────────────────────
map.on("click", (e) => {
    const { lat, lng } = e.latlng;
    placeMarker(lat, lng);
    inputLat.value = lat.toFixed(5);
    inputLon.value = lng.toFixed(5);
    runAnalysis(lat, lng);
});

// ── Search button ─────────────────────────────────────────────
btnSearch.addEventListener("click", () => {
    const lat = parseFloat(inputLat.value);
    const lon = parseFloat(inputLon.value);
    if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
        shakeElement(btnSearch);
        return;
    }
    placeMarker(lat, lon);
    map.flyTo([lat, lon], 10, { duration: 1.5 });
    runAnalysis(lat, lon);
});

// Enter key on inputs
[inputLat, inputLon].forEach(el => {
    el.addEventListener("keydown", (e) => {
        if (e.key === "Enter") btnSearch.click();
    });
});

// ── Close panel ───────────────────────────────────────────────
btnClose.addEventListener("click", () => {
    resultsPanel.classList.add("hidden");
});

// ── Place marker ──────────────────────────────────────────────
function placeMarker(lat, lon) {
    if (currentMarker) map.removeLayer(currentMarker);

    const icon = L.divIcon({
        className: "",
        html: `<div class="marker-pulse"></div><div class="custom-marker"></div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 28],
    });

    currentMarker = L.marker([lat, lon], { icon }).addTo(map);
    coordDisplay.textContent = `${lat.toFixed(5)}, ${lon.toFixed(5)}`;
}

// ── API Call – Assessment ─────────────────────────────────────
const satelliteObservation = document.getElementById("satellite-observation");
let observationRequest;

async function fetchSatelliteObservation(lat, lon) {
    observationRequest?.abort();
    const request = new AbortController();
    observationRequest = request;
    satelliteObservation.hidden = true;
    try {
        const query = new URLSearchParams({ lat, lon });
        const response = await fetch(`${API_BASE}/api/flood-observation?${query}`, {
            signal: request.signal,
        });
        if (!response.ok) return;
        const observation = await response.json();
        if (request.signal.aborted || observation.status !== "available") return;
        const classification = observation.water_detected
            ? "water detected" : "water not detected";
        satelliteObservation.textContent =
            `Satellite observation on ${observation.acquired_on}: ${classification} at this point (${observation.source}).`;
        satelliteObservation.hidden = false;
    } catch (error) {
        if (error.name !== "AbortError") console.warn("Satellite observation unavailable", error);
    }
}

async function runAnalysis(lat, lon) {
    observationRequest?.abort();
    satelliteObservation.hidden = true;
    showLoading(true);
    resultsPanel.classList.add("hidden");
    // Reset calamity tab
    calamityCards.dataset.loaded = "";
    calamityCards.innerHTML = "";
    // Reset history tab
    historyTimeline.dataset.loaded = "";
    _historyData = null;
    _historyActiveFilter = "all";
    [historySummary, historyTypeSection, historyDecadeSection,
     historyTimelineSection, historyEmpty].forEach(el => el.classList.add("hidden"));

    // Switch to assessment tab
    tabBtns.forEach(b => b.classList.remove("active"));
    tabContents.forEach(tc => tc.classList.remove("active"));
    document.getElementById("tab-btn-assessment").classList.add("active");
    document.getElementById("tab-assessment").classList.add("active");

    lastAnalysedLat = lat;
    lastAnalysedLon = lon;

    try {
        const resp = await fetch(`${API_BASE}/api/score?lat=${lat}&lon=${lon}`);
        if (!resp.ok) throw new Error(`API error: ${resp.status}`);
        const data = await resp.json();
        renderResults(data);
    } catch (err) {
        console.error("Analysis failed:", err);
        alert("Analysis failed. Make sure the backend is running.\n\n" + err.message);
    } finally {
        showLoading(false);
    }
}

// ── API Call – Calamity ───────────────────────────────────────
async function fetchCalamityData(lat, lon) {
    void fetchSatelliteObservation(lat, lon);
    calamityLoading.classList.remove("hidden");
    calamityCards.innerHTML = "";
    hazardSummaryText.textContent = "Analysing hazard data...";
    hazardLevel.textContent = "...";

    try {
        const resp = await fetch(`${API_BASE}/api/calamity?lat=${lat}&lon=${lon}`);
        if (!resp.ok) throw new Error(`API error: ${resp.status}`);
        const data = await resp.json();
        renderCalamity(data);
        calamityCards.dataset.loaded = "true";
    } catch (err) {
        console.error("Calamity fetch failed:", err);
        calamityCards.innerHTML = `<div style="padding:16px;color:var(--text-muted);font-size:0.82rem;">
            Failed to fetch hazard data. Make sure the backend is running.<br>
            <span style="color:var(--color-poor)">${err.message}</span>
        </div>`;
    } finally {
        calamityLoading.classList.add("hidden");
    }
}

// ── API Call – History ────────────────────────────────────────
async function fetchHistoryData(lat, lon) {
    historyLoading.classList.remove("hidden");
    [historySummary, historyTypeSection, historyDecadeSection,
     historyTimelineSection, historyEmpty].forEach(el => el.classList.add("hidden"));

    try {
        const resp = await fetch(`${API_BASE}/api/history?lat=${lat}&lon=${lon}`);
        if (!resp.ok) throw new Error(`API error: ${resp.status}`);
        const data = await resp.json();
        _historyData = data;
        renderHistory(data);
        historyTimeline.dataset.loaded = "true";
    } catch (err) {
        console.error("History fetch failed:", err);
        historyTimeline.innerHTML = `<div style="padding:16px;color:var(--text-muted);font-size:0.82rem;">
            Failed to fetch history. <span style="color:var(--color-poor)">${err.message}</span>
        </div>`;
        historyTimelineSection.classList.remove("hidden");
    } finally {
        historyLoading.classList.add("hidden");
    }
}

// ── Render Assessment Results ─────────────────────────────────
function renderResults(data) {
    // Location
    resultLocation.textContent = `${data.coordinates.lat.toFixed(5)}, ${data.coordinates.lon.toFixed(5)}`;

    // Verdict Banner
    if (data.verdict) {
        verdictCard.classList.remove("hidden");
        const v = data.verdict;
        verdictBadge.textContent = v.badge || "RECOMMENDED";
        verdictBadge.style.background = `${v.badge_color || "#22c55e"}22`;
        verdictBadge.style.color = v.badge_color || "#22c55e";
        verdictBadge.style.borderColor = `${v.badge_color || "#22c55e"}66`;
        verdictTitle.textContent = v.verdict_title || "Construction Suitability";
        verdictSummary.textContent = v.summary || "";

        if (v.recommendations && v.recommendations.length > 0) {
            verdictRecsList.innerHTML = v.recommendations.map(r => `<li>${r}</li>`).join("");
        } else {
            verdictRecsList.innerHTML = "<li>Follow standard building code regulations.</li>";
        }
    } else {
        verdictCard.classList.add("hidden");
    }

    // Gauges
    animateGauge("ring-construction", "val-construction", data.construction_score, getScoreColor(data.construction_score));
    animateGauge("ring-habitability", "val-habitability", data.habitability_score, getScoreColor(data.habitability_score));
    animateGauge("ring-overall",      "val-overall",      data.overall_score,      getScoreColor(data.overall_score));

    // Factors
    factorsList.innerHTML = "";
    const factorOrder = ["slope", "elevation", "climate", "soil", "seismic", "flood", "access", "land_cover"];
    const factorIcons = {
        slope: "⛰️", elevation: "📏", climate: "🌡️", soil: "🪨",
        seismic: "🌊", flood: "💧", access: "🛣️", land_cover: "🛰️"
    };

    for (const key of factorOrder) {
        const f = data.factors[key];
        if (!f) continue;
        const color = getScoreColor(f.score);
        const ratingClass = `rating-${f.rating.toLowerCase()}`;

        const row = document.createElement("div");
        row.className = "factor-row";
        row.innerHTML = `
            <span class="factor-name">${factorIcons[key] || "📊"} ${key}</span>
            <div class="factor-bar-track">
                <div class="factor-bar-fill" style="background:${color};" data-width="${f.score}"></div>
            </div>
            <span class="factor-score" style="color:${color};">${Math.round(f.score)}</span>
            <span class="factor-rating ${ratingClass}">${f.rating}</span>
        `;
        factorsList.appendChild(row);

        // Animate bar after append
        requestAnimationFrame(() => {
            const fill = row.querySelector(".factor-bar-fill");
            fill.style.width = f.score + "%";
        });
    }

    // Details
    renderDetails(data);

    // Warnings
    if (data.warnings && data.warnings.length > 0) {
        warningsSection.classList.remove("hidden");
        warningsList.innerHTML = data.warnings.map(w => `<li>${w}</li>`).join("");
    } else {
        warningsSection.classList.add("hidden");
    }

    // Hard constraints
    if (data.hard_constraints && data.hard_constraints.length > 0) {
        constraintsSection.classList.remove("hidden");
        constraintsList.innerHTML = data.hard_constraints.map(c => `<li>${c}</li>`).join("");
    } else {
        constraintsSection.classList.add("hidden");
    }

    // Sources
    if (data.phase_sources) {
        sourcesList.innerHTML = Object.values(data.phase_sources)
            .map(s => `<span class="source-tag">${s}</span>`)
            .join("");
    }

    // Show panel
    resultsPanel.classList.remove("hidden");
}

// ── Details Rendering ─────────────────────────────────────────
function renderDetails(data) {
    let html = '<h3>Key Metrics</h3><div class="detail-grid">';

    if (data.terrain) {
        const t = data.terrain;
        if (t.center_elevation_m != null) {
            html += detailCard("Elevation", `${Math.round(t.center_elevation_m)} m`);
        }
        if (t.max_slope_pct != null) {
            html += detailCard("Max Slope", `${t.max_slope_pct.toFixed(1)}%`);
        }
    }

    if (data.climate) {
        const c = data.climate;
        if (c.avg_temp_c != null) html += detailCard("Avg Temp", `${c.avg_temp_c}°C`);
        if (c.annual_rainfall_mm != null) html += detailCard("Annual Rain", `${Math.round(c.annual_rainfall_mm)} mm`);
        if (c.max_temp_c != null) html += detailCard("Max Temp", `${c.max_temp_c}°C`);
        if (c.min_temp_c != null) html += detailCard("Min Temp", `${c.min_temp_c}°C`);
        if (c.avg_humidity_pct != null) html += detailCard("Humidity", `${c.avg_humidity_pct}%`);
        if (c.avg_wind_kmh != null) html += detailCard("Avg Wind", `${c.avg_wind_kmh} km/h`);
    }

    if (data.soil) {
        const s = data.soil;
        if (s.clay_pct != null) html += detailCard("Clay", `${s.clay_pct}%`);
        if (s.sand_pct != null) html += detailCard("Sand", `${s.sand_pct}%`);
        if (s.ph != null) html += detailCard("Soil pH", s.ph.toFixed(1));
    }

    if (data.seismic) {
        const s = data.seismic;
        html += detailCard("Quakes (M4+)", `${s.earthquake_count}`);
        if (s.max_magnitude != null) html += detailCard("Max Mag", `M${s.max_magnitude}`);
    }

    if (data.access) {
        const a = data.access;
        if (a.nearest_road_km != null) html += detailCard("Nearest Road", `${a.nearest_road_km} km`);
        html += detailCard("Water Supply", a.water_supply_nearby ? "✅ Nearby" : "❌ None found");
    }

    html += '</div>';
    detailsSection.innerHTML = html;
}

function detailCard(label, value) {
    return `<div class="detail-card">
        <div class="detail-label">${label}</div>
        <div class="detail-value">${value}</div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// CALAMITY RENDERING
// ═══════════════════════════════════════════════════════════════

function renderCalamity(data) {
    // Overall hazard ring
    const overallScore = data.overall_risk_score || 0;
    const overallColor = getRiskColor(overallScore);

    const ring = document.getElementById("ring-hazard-overall");
    const val = document.getElementById("val-hazard-overall");
    const offset = CIRCUMFERENCE_HAZARD - (overallScore / 100) * CIRCUMFERENCE_HAZARD;

    ring.style.stroke = overallColor;
    ring.style.strokeDashoffset = CIRCUMFERENCE_HAZARD; // reset
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            ring.style.strokeDashoffset = offset;
        });
    });
    animateNumber(val, 0, Math.round(overallScore), 1000);

    // Level label
    hazardLevel.textContent = data.overall_risk_level || "Unknown";
    hazardLevel.style.color = overallColor;

    // Summary text
    hazardSummaryText.textContent = data.summary || "";

    // History influence badge
    const hs = data.history_summary;
    if (hs && hs.total_events > 0) {
        const badge = document.createElement("div");
        badge.className = "history-influence-badge";
        badge.innerHTML = `📚 Calibrated with <strong>${hs.total_events}</strong> historical events`
            + (hs.earliest_year ? ` since ${hs.earliest_year}` : "")
            + (hs.most_frequent ? ` · Most common: <strong>${hs.most_frequent}</strong>` : "");
        // Insert after summary text
        const existing = document.querySelector(".history-influence-badge");
        if (existing) existing.remove();
        document.getElementById("hazard-summary").appendChild(badge);
    }

    // Point-specific screening verdict
    const outlook = data.pinpoint_outlook || {};
    const outlookClass = {
        elevated: "elevated",
        no_high_risk_detected: "no-high-risk",
        insufficient_data: "unknown",
    }[outlook.status] || "unknown";
    pinpointOutlook.className = `pinpoint-outlook ${outlookClass}`;
    pinpointOutlookLabel.textContent = outlook.label || "Outlook unavailable";
    pinpointOutlookMessage.textContent = outlook.message || "No point-specific outlook is available.";
    const topHazard = outlook.top_hazard;
    pinpointOutlookDetail.textContent = topHazard
        ? `Strongest signal: ${topHazard.type} (${topHazard.risk_score}/100, ${topHazard.risk_level}) · ${topHazard.time_horizon}`
        : "";

    // Risk count badges
    highRiskCount.textContent = data.high_risk_count || 0;
    moderateRiskCount.textContent = data.moderate_risk_count || 0;

    // Calamity cards
    calamityCards.innerHTML = "";
    const predictions = data.predictions || [];

    predictions.forEach((pred, idx) => {
        const riskClass = getRiskLevelClass(pred.risk_level);
        const riskColor = getRiskColor(pred.risk_score);

        const card = document.createElement("div");
        card.className = `calamity-card ${riskClass}`;
        card.style.animationDelay = `${idx * 0.06}s`;
        card.style.animation = `fadeIn 0.4s ease ${idx * 0.06}s both`;

        const histBadge = pred.history_adjusted
            ? `<span class="hist-badge" title="Adjusted by historical event frequency">+${pred.history_boost} hist</span>`
            : "";
        const calBadge = pred.calibrated
            ? `<span class="cal-badge" title="Calibrated against known city data">✓ calibrated</span>`
            : "";

        card.innerHTML = `
            <div class="calamity-card-header">
                <div class="calamity-emoji">${pred.emoji || "⚡"}</div>
                <div class="calamity-card-info">
                    <div class="calamity-card-name">${pred.type} ${histBadge}${calBadge}</div>
                    <div class="calamity-card-prob">${pred.probability_text || ""}</div>
                </div>
                <div class="calamity-card-score">
                    <span class="calamity-score-value" style="color:${riskColor}">${Math.round(pred.risk_score)}</span>
                    <span class="calamity-score-level">${pred.risk_level}</span>
                </div>
            </div>
            <div class="calamity-risk-bar">
                <div class="calamity-risk-bar-fill" style="background:${riskColor};" data-width="${pred.risk_score}"></div>
            </div>
            <div class="calamity-card-detail">
                <div class="calamity-detail-row">
                    <div class="calamity-detail-title">Analysis</div>
                    <div class="calamity-detail-text">${pred.detail || "No details available"}</div>
                    <span class="calamity-time-horizon">${pred.time_horizon || ""}</span>
                </div>
                ${pred.factors && pred.factors.length > 0 ? `
                <div class="calamity-detail-row">
                    <div class="calamity-detail-title">Contributing Factors</div>
                    <ul class="calamity-factors-list">
                        ${pred.factors.map(f => `<li>${f}</li>`).join("")}
                    </ul>
                </div>` : ""}
                ${pred.mitigations && pred.mitigations.length > 0 ? `
                <div class="calamity-detail-row">
                    <div class="calamity-detail-title">Recommended Mitigations</div>
                    <ul class="calamity-mitigations-list">
                        ${pred.mitigations.map(m => `<li>${m}</li>`).join("")}
                    </ul>
                </div>` : ""}
            </div>
        `;

        // Click to expand/collapse
        const header = card.querySelector(".calamity-card-header");
        header.addEventListener("click", () => {
            card.classList.toggle("expanded");
        });

        calamityCards.appendChild(card);

        // Animate risk bar
        requestAnimationFrame(() => {
            const fill = card.querySelector(".calamity-risk-bar-fill");
            fill.style.width = pred.risk_score + "%";
        });
    });
}

// ═══════════════════════════════════════════════════════════════
// HISTORY RENDERING
// ═══════════════════════════════════════════════════════════════

const HISTORY_TYPE_EMOJI = {
    earthquake: "🌍", flood: "🌊", cyclone: "🌀",
    wildfire: "🔥", volcanic: "🌋", drought: "☀️",
    tsunami: "🌊", landslide: "⛰️", other: "⚡"
};

const SEVERITY_COLOR = {
    extreme:  "#ef4444",
    severe:   "#f97316",
    moderate: "#eab308",
    minor:    "#84cc16",
    unknown:  "#6b7280",
};

function renderHistory(data) {
    const events = data.events || [];
    const typeCounts  = data.type_counts  || {};
    const decadeCounts = data.decade_counts || {};

    // ── Summary stats ──
    historySummary.classList.remove("hidden");
    historyStatRow.innerHTML = [
        { label: "Total Events", value: data.total_events || 0 },
        { label: "Radius",       value: `${data.search_radius_km || 300} km` },
        { label: "Earliest",     value: data.earliest_year || "—" },
        { label: "Most Common",  value: data.most_frequent ? (HISTORY_TYPE_EMOJI[data.most_frequent] || "⚡") + " " + data.most_frequent : "—" },
    ].map(s => `
        <div class="history-stat">
            <div class="history-stat-value">${s.value}</div>
            <div class="history-stat-label">${s.label}</div>
        </div>
    `).join("");

    historySources.innerHTML = (data.sources_used || [])
        .map(s => `<span class="source-tag">📡 ${s}</span>`).join("");

    // ── Type frequency bars ──
    const typeEntries = Object.entries(typeCounts).sort((a, b) => b[1] - a[1]);
    if (typeEntries.length > 0) {
        historyTypeSection.classList.remove("hidden");
        const maxCount = typeEntries[0][1];
        historyTypeBars.innerHTML = typeEntries.map(([type, count]) => {
            const pct = Math.round((count / maxCount) * 100);
            const color = getTypeColor(type);
            return `
            <div class="hbar-row">
                <div class="hbar-label">${HISTORY_TYPE_EMOJI[type] || "⚡"} ${type}</div>
                <div class="hbar-track">
                    <div class="hbar-fill" style="background:${color};width:0%" data-pct="${pct}"></div>
                </div>
                <div class="hbar-count">${count}</div>
            </div>`;
        }).join("");

        // Animate bars
        requestAnimationFrame(() => {
            historyTypeBars.querySelectorAll(".hbar-fill").forEach(bar => {
                bar.style.width = bar.dataset.pct + "%";
            });
        });
    }

    // ── Decade chart ──
    const decadeEntries = Object.entries(decadeCounts).sort((a, b) => a[0].localeCompare(b[0]));
    if (decadeEntries.length > 0) {
        historyDecadeSection.classList.remove("hidden");
        const maxD = Math.max(...decadeEntries.map(([,v]) => v));
        historyDecadeBars.innerHTML = decadeEntries.map(([decade, count]) => {
            const pct = Math.round((count / maxD) * 100);
            return `
            <div class="decade-bar-col">
                <div class="decade-bar-wrap">
                    <div class="decade-bar-fill" style="height:0%" data-pct="${pct}"></div>
                </div>
                <div class="decade-bar-label">${decade}</div>
                <div class="decade-bar-count">${count}</div>
            </div>`;
        }).join("");

        requestAnimationFrame(() => {
            historyDecadeBars.querySelectorAll(".decade-bar-fill").forEach(bar => {
                bar.style.height = bar.dataset.pct + "%";
            });
        });
    }

    // ── Filter buttons + Timeline ──
    if (events.length === 0) {
        historyEmpty.classList.remove("hidden");
        return;
    }

    historyTimelineSection.classList.remove("hidden");

    // Build filter buttons
    const allTypes = ["all", ...Object.keys(typeCounts).sort()];
    historyFilterRow.innerHTML = allTypes.map(t => `
        <button class="hist-filter-btn ${t === "all" ? "active" : ""}" data-type="${t}">
            ${t === "all" ? "All" : (HISTORY_TYPE_EMOJI[t] || "⚡") + " " + t}
            <span class="hist-filter-count">${t === "all" ? events.length : (typeCounts[t] || 0)}</span>
        </button>
    `).join("");

    historyFilterRow.querySelectorAll(".hist-filter-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            historyFilterRow.querySelectorAll(".hist-filter-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            _historyActiveFilter = btn.dataset.type;
            renderTimelineEvents(events, _historyActiveFilter);
        });
    });

    renderTimelineEvents(events, "all");
}

function renderTimelineEvents(events, filterType) {
    const filtered = filterType === "all"
        ? events
        : events.filter(e => e.type === filterType);

    if (filtered.length === 0) {
        historyTimeline.innerHTML = `<div class="timeline-empty">No ${filterType} events recorded in this area.</div>`;
        return;
    }

    historyTimeline.innerHTML = filtered.map((ev, idx) => {
        const sevColor  = SEVERITY_COLOR[ev.severity] || SEVERITY_COLOR.unknown;
        const sevLabel  = (ev.severity || "unknown").charAt(0).toUpperCase() + (ev.severity || "unknown").slice(1);
        const distText  = ev.distance_km != null ? `~${ev.distance_km} km away` : "";
        const srcBadge  = `<span class="timeline-source">${ev.source || ""}</span>`;
        const magText   = ev.magnitude ? `M${ev.magnitude}` : "";

        return `
        <div class="timeline-item" style="animation-delay:${idx * 0.03}s">
            <div class="timeline-dot" style="background:${sevColor}"></div>
            <div class="timeline-content">
                <div class="timeline-header">
                    <span class="timeline-emoji">${ev.emoji || "⚡"}</span>
                    <span class="timeline-title">${ev.title || "Unknown event"}</span>
                    ${magText ? `<span class="timeline-mag">${magText}</span>` : ""}
                </div>
                <div class="timeline-meta">
                    <span class="timeline-date">📅 ${ev.date || "Unknown date"}</span>
                    ${distText ? `<span class="timeline-dist">📍 ${distText}</span>` : ""}
                    <span class="timeline-sev" style="color:${sevColor}">${sevLabel}</span>
                    ${srcBadge}
                </div>
                ${ev.detail && ev.detail !== ev.title ? `<div class="timeline-detail">${ev.detail}</div>` : ""}
            </div>
        </div>`;
    }).join("");
}

function getTypeColor(type) {
    const colors = {
        earthquake: "#f97316",
        flood:      "#3b82f6",
        cyclone:    "#8b5cf6",
        wildfire:   "#ef4444",
        volcanic:   "#dc2626",
        drought:    "#eab308",
        tsunami:    "#06b6d4",
        landslide:  "#78716c",
        other:      "#6b7280",
    };
    return colors[type] || "#6b7280";
}

// ── Gauge Animation ───────────────────────────────────────────
function animateGauge(ringId, valId, score, color) {
    const ring = document.getElementById(ringId);
    const val  = document.getElementById(valId);

    const offset = CIRCUMFERENCE - (score / 100) * CIRCUMFERENCE;

    ring.style.stroke = color;
    ring.style.strokeDashoffset = CIRCUMFERENCE; // reset

    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            ring.style.strokeDashoffset = offset;
        });
    });

    // Count-up animation
    animateNumber(val, 0, Math.round(score), 1000);
}

function animateNumber(el, from, to, duration) {
    const start = performance.now();
    function tick(now) {
        const t = Math.min((now - start) / duration, 1);
        const ease = 1 - Math.pow(1 - t, 3); // ease-out cubic
        el.textContent = Math.round(from + (to - from) * ease);
        if (t < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
}

// ── Utility ───────────────────────────────────────────────────
function getScoreColor(score) {
    if (score >= 80) return "#22c55e";
    if (score >= 65) return "#84cc16";
    if (score >= 45) return "#eab308";
    if (score >= 25) return "#f97316";
    return "#ef4444";
}

function getRiskColor(score) {
    if (score >= 80) return "#ef4444";
    if (score >= 60) return "#f97316";
    if (score >= 40) return "#eab308";
    if (score >= 20) return "#84cc16";
    return "#22c55e";
}

function getRiskLevelClass(level) {
    if (!level) return "risk-level-low";
    const l = level.toLowerCase().replace(/\s+/g, "-");
    return `risk-level-${l}`;
}

function showLoading(visible) {
    loadingOverlay.classList.toggle("hidden", !visible);
}

function shakeElement(el) {
    el.style.animation = "none";
    el.offsetHeight; // reflow
    el.style.animation = "shake 0.4s ease";
    setTimeout(() => el.style.animation = "", 400);
}

// Add shake keyframes dynamically
const style = document.createElement("style");
style.textContent = `@keyframes shake {
    0%, 100% { transform: translateX(0); }
    20% { transform: translateX(-4px); }
    40% { transform: translateX(4px); }
    60% { transform: translateX(-3px); }
    80% { transform: translateX(3px); }
}`;
document.head.appendChild(style);
