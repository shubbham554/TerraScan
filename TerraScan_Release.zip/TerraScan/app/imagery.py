"""
Phase 6 · Imagery integration
Loads pre-computed Prithvi features (saved from the Colab notebook)
and turns them into a land-cover factor score.
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional
from app.config import PRITHVI_FEATURES_DIR
from app.hls_index import load_hls_features


def load_prithvi_features(lat: float, lon: float) -> Optional[Dict[str, Any]]:
    """
    Look for a cached Prithvi output file for the given coordinates.
    Files are saved by the Colab notebook as:
        prithvi_features/<lat>_<lon>.json
    """
    # Normalise filename
    fname = f"{lat:.4f}_{lon:.4f}.json"
    path = os.path.join(PRITHVI_FEATURES_DIR, fname)

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("dominant_class"), str):
            return data
    except (OSError, ValueError):
        pass
    return load_hls_features(Path(os.getenv("TERRASCAN_HLS_DIR", "data/hls")), lat, lon)


def save_prithvi_features(lat: float, lon: float, features: Dict[str, Any]) -> str:
    """Save Prithvi outputs so the FastAPI server can pick them up."""
    os.makedirs(PRITHVI_FEATURES_DIR, exist_ok=True)
    fname = f"{lat:.4f}_{lon:.4f}.json"
    path = os.path.join(PRITHVI_FEATURES_DIR, fname)
    with open(path, "w") as f:
        json.dump(features, f, indent=2)
    return path
