"""
Phases 1-4 · Scoring engine
Converts raw values into 0-100 factor scores and combines them
into construction and habitability percentages.
"""

from typing import Dict, Any, List, Tuple, Optional
from app.config import (
    SLOPE_BREAKPOINTS, ELEVATION_BREAKPOINTS,
    TEMP_BREAKPOINTS, HUMIDITY_BREAKPOINTS, RAINFALL_BREAKPOINTS,
    CLAY_BREAKPOINTS, SEISMIC_BREAKPOINTS, ACCESS_BREAKPOINTS,
    CONSTRUCTION_WEIGHTS, HABITABILITY_WEIGHTS,
    HARD_SLOPE_LIMIT, HARD_ELEVATION_LIMIT,
)
from app.models import (
    FactorScore, AssessmentResult, Coordinates,
    TerrainDetail, ClimateDetail, SoilDetail,
    SeismicDetail, AccessDetail, LandCoverDetail,
    ConstructionVerdict,
)


# ═══════════════════════════════════════════════════════════════════
# Core interpolation
# ═══════════════════════════════════════════════════════════════════

def _lerp(value: float, breakpoints: List[Tuple[float, float]]) -> float:
    """
    Piecewise-linear interpolation.
    breakpoints = [(x0, y0), (x1, y1), ...] sorted by x ascending.
    """
    if value <= breakpoints[0][0]:
        return float(breakpoints[0][1])
    if value >= breakpoints[-1][0]:
        return float(breakpoints[-1][1])
    for i in range(len(breakpoints) - 1):
        x0, y0 = breakpoints[i]
        x1, y1 = breakpoints[i + 1]
        if x0 <= value <= x1:
            t = (value - x0) / (x1 - x0) if x1 != x0 else 0
            return float(y0 + t * (y1 - y0))
    return float(breakpoints[-1][1])


def _rating(score: float) -> str:
    if score >= 85:
        return "Excellent"
    if score >= 65:
        return "Good"
    if score >= 45:
        return "Moderate"
    if score >= 25:
        return "Fair"
    return "Poor"


# ═══════════════════════════════════════════════════════════════════
# Individual factor scores
# ═══════════════════════════════════════════════════════════════════

def score_slope(terrain: Dict[str, Any]) -> FactorScore:
    val = terrain.get("max_slope_pct")
    if val is None:
        return FactorScore(score=50, rating="Unknown", unit="%", detail="Slope data unavailable")
    s = _lerp(val, SLOPE_BREAKPOINTS)
    return FactorScore(value=round(val, 1), unit="%", score=round(s, 1), rating=_rating(s))


def score_elevation(terrain: Dict[str, Any]) -> FactorScore:
    val = terrain.get("center_elevation")
    if val is None:
        val = terrain.get("mean_elevation")
    if val is None:
        return FactorScore(score=50, rating="Unknown", unit="m", detail="Elevation data unavailable")
    s = _lerp(val, ELEVATION_BREAKPOINTS)
    return FactorScore(value=round(val, 1), unit="m", score=round(s, 1), rating=_rating(s))


def score_climate(climate: Dict[str, Any]) -> FactorScore:
    """Composite climate comfort from temperature, humidity, rainfall."""
    scores = []

    avg_t = climate.get("avg_temp_c")
    if avg_t is not None:
        scores.append(("temp", _lerp(avg_t, TEMP_BREAKPOINTS), 0.40))

    hum = climate.get("avg_humidity_pct")
    if hum is not None:
        scores.append(("humidity", _lerp(hum, HUMIDITY_BREAKPOINTS), 0.25))

    rain = climate.get("annual_rainfall_mm")
    if rain is not None:
        scores.append(("rain", _lerp(rain, RAINFALL_BREAKPOINTS), 0.25))

    # Extreme-days penalty
    hot = climate.get("hot_days_per_year", 0) or 0
    cold = climate.get("cold_days_per_year", 0) or 0
    extreme_days = hot + cold
    extreme_score = max(0, 100 - extreme_days * 1.5)
    scores.append(("extreme", extreme_score, 0.10))

    if not scores:
        return FactorScore(score=50, rating="Unknown", detail="Climate data unavailable")

    total_w = sum(w for _, _, w in scores)
    composite = sum(s * w for _, s, w in scores) / total_w if total_w else 50

    detail_parts = []
    if avg_t is not None:
        detail_parts.append(f"Avg {avg_t}°C")
    if rain is not None:
        detail_parts.append(f"{rain} mm/yr rain")
    if hum is not None:
        detail_parts.append(f"{hum}% humidity")

    return FactorScore(
        value=round(avg_t, 1) if avg_t else None,
        unit="C (avg)",
        score=round(composite, 1),
        rating=_rating(composite),
        detail=", ".join(detail_parts) if detail_parts else None,
    )


def score_soil(soil: Dict[str, Any]) -> FactorScore:
    clay = soil.get("clay_pct")
    if clay is None:
        return FactorScore(score=50, rating="Unknown", unit="%", detail="Soil data unavailable")
    s = _lerp(clay, CLAY_BREAKPOINTS)
    detail = f"Clay {clay}%"
    sand = soil.get("sand_pct")
    if sand is not None:
        detail += f", Sand {sand}%"
    return FactorScore(value=round(clay, 1), unit="% clay", score=round(s, 1), rating=_rating(s), detail=detail)


def score_seismic(seis: Dict[str, Any]) -> FactorScore:
    count = seis.get("earthquake_count", 0)
    s = _lerp(count, SEISMIC_BREAKPOINTS)
    detail = f"{count} M4+ quakes in {seis.get('search_radius_km', 200)} km"
    if seis.get("max_magnitude"):
        detail += f", max M{seis['max_magnitude']}"
    return FactorScore(value=float(count), unit="events", score=round(s, 1), rating=_rating(s), detail=detail)


def score_access(infra: Dict[str, Any]) -> FactorScore:
    nearest = infra.get("nearest_road_km", 15)
    s = _lerp(nearest, ACCESS_BREAKPOINTS)
    detail = f"~{nearest} km to nearest road"
    if infra.get("water_supply_nearby"):
        detail += ", water supply nearby"
    return FactorScore(value=round(nearest, 1), unit="km", score=round(s, 1), rating=_rating(s), detail=detail)


def _is_major_flood_basin(lat: float, lon: float) -> Tuple[bool, str]:
    """Identify well-documented high-hazard river flood basins."""
    if 24.0 <= lat <= 28.5 and 89.5 <= lon <= 96.5:
        return True, "Brahmaputra/Barak Basin (Assam Floodplain)"
    if 25.0 <= lat <= 27.8 and 84.0 <= lon <= 88.5:
        return True, "Ganga-Kosi Basin (North Bihar Floodplain)"
    if 21.5 <= lat <= 24.2 and 87.5 <= lon <= 90.5:
        return True, "Lower Bengal Delta Floodplain"
    if 19.5 <= lat <= 21.5 and 85.0 <= lon <= 87.2:
        return True, "Mahanadi Delta Floodplain"
    return False, ""


def score_flood(
    terrain: Dict[str, Any],
    climate: Dict[str, Any],
    lat: Optional[float] = None,
    lon: Optional[float] = None,
    flood_data: Optional[Dict[str, Any]] = None,
) -> FactorScore:
    """
    Flood suitability scoring based on elevation, precipitation, slope,
    hydrological basins, and real-time GloFAS river discharge.
    """
    elev = terrain.get("center_elevation") or terrain.get("mean_elevation") or 500
    rain = climate.get("annual_rainfall_mm") or 800
    slope = terrain.get("mean_slope_pct") or 5
    heavy_rain_days = climate.get("heavy_rain_days_per_year") or 0

    risk = 0  # 0 = safe, 100 = extreme risk
    basin_info = ""
    in_basin = False

    # Known high-hazard flood basins (Assam, Kosi, Bengal, Mahanadi)
    if lat is not None and lon is not None:
        in_basin, b_name = _is_major_flood_basin(lat, lon)
        if in_basin and elev < 200:
            basin_risk = 45 if elev < 80 else 32
            risk += basin_risk
            basin_info = f" [{b_name}]"

    # Low elevation near sea level or valley bottom
    if elev < 5:
        risk += 24
    elif elev < 15:
        risk += 14
    elif elev < 35:
        risk += 8
    elif elev < 70:
        risk += 3

    # Heavy rainfall
    if rain > 3500:
        risk += 24
    elif rain > 2500:
        risk += 16
    elif rain > 1800:
        risk += 10
    elif rain > 1200:
        risk += 4
    elif rain > 800:
        risk += 1

    # Flat terrain collects water in low-lying coastal zones or river flood basins
    if (elev < 25 or in_basin):
        if slope < 1:
            risk += 12
        elif slope < 2.5:
            risk += 6

    # Frequent heavy rain events
    if heavy_rain_days > 40:
        risk += 12
    elif heavy_rain_days > 25:
        risk += 6

    # GloFAS River discharge
    if flood_data and flood_data.get("river_discharge_m3s"):
        dis = flood_data["river_discharge_m3s"]
        if dis > 150:
            risk += min(18, dis / 25)

    risk = min(risk, 90)

    score = max(0, 100 - risk)
    return FactorScore(
        value=round(risk, 1),
        unit="risk index",
        score=round(score, 1),
        rating=_rating(score),
        detail=f"Elev {elev:.0f}m, slope {slope:.1f}%, rain {rain:.0f}mm/yr{basin_info}",
    )


# ═══════════════════════════════════════════════════════════════════
# Phase 6 – Land cover (from Prithvi features, if available)
# ═══════════════════════════════════════════════════════════════════

def score_land_cover(land_cover: Optional[Dict[str, Any]]) -> Optional[FactorScore]:
    """Score from Prithvi-derived land cover classification."""
    if not land_cover or "dominant_class" not in land_cover:
        return None

    cls = land_cover.get("dominant_class", "unknown").lower()
    water_pct = land_cover.get("water_pct", 0) or 0
    built_pct = land_cover.get("built_pct", 0) or 0

    # Water bodies are unbuildable
    if water_pct > 50:
        detail = "Mostly water - unsuitable"
        if land_cover.get("source") == "NASA HLS V2.0 Fmask":
            detail = f'Mostly water in NASA HLS imagery acquired {land_cover["acquired_utc"][:10]}'
        return FactorScore(value=water_pct, unit="% water", score=5, rating="Poor",
                           detail=detail)

    score_map = {
        "barren":     85,   # easy to build on
        "grassland":  80,
        "cropland":   70,   # fertile but convertible
        "shrubland":  65,
        "forest":     40,   # clearing needed
        "wetland":    15,
        "water":       5,
        "built":      60,   # already developed, check density
        "snow_ice":   10,
    }
    s = score_map.get(cls, 50)
    return FactorScore(value=s, unit="class", score=s, rating=_rating(s),
                       detail=f"Dominant: {cls}")


# ═══════════════════════════════════════════════════════════════════
# Weighted combination
# ═══════════════════════════════════════════════════════════════════

def _weighted(factors: Dict[str, FactorScore], weights: Dict[str, float]) -> float:
    total_w, total_s = 0.0, 0.0
    for key, w in weights.items():
        if key in factors:
            total_s += factors[key].score * w
            total_w += w
    return round(total_s / total_w, 1) if total_w > 0 else 50.0


# ═══════════════════════════════════════════════════════════════════
# Hard constraints
# ═══════════════════════════════════════════════════════════════════

def check_hard_constraints(terrain: Dict, climate: Dict) -> List[str]:
    constraints = []
    slope = terrain.get("max_slope_pct", 0)
    elev = terrain.get("center_elevation") or terrain.get("mean_elevation", 0)
    if slope > HARD_SLOPE_LIMIT:
        constraints.append(f"CRITICAL: Slope {slope:.0f}% exceeds {HARD_SLOPE_LIMIT}% — terrain nearly unbuildable")
    if elev > HARD_ELEVATION_LIMIT:
        constraints.append(f"CRITICAL: Elevation {elev:.0f}m exceeds {HARD_ELEVATION_LIMIT}m — extreme altitude")
    return constraints


def generate_warnings(factors: Dict[str, FactorScore], terrain: Dict, climate: Dict, seis: Dict) -> List[str]:
    warnings = []
    if factors.get("slope") and factors["slope"].score < 30:
        warnings.append("Steep terrain — significant earthwork required for construction")
    if factors.get("seismic") and factors["seismic"].score < 50:
        mag = seis.get("max_magnitude", "?")
        warnings.append(f"Seismic zone — {seis.get('earthquake_count', 0)} M4+ quakes recorded (max M{mag})")
    if factors.get("flood") and factors["flood"].score < 40:
        warnings.append("Elevated flood risk — consider drainage and raised foundations")
    if factors.get("climate") and factors["climate"].score < 35:
        warnings.append("Harsh climate — extreme temperatures or heavy precipitation")
    if factors.get("soil") and factors["soil"].score < 35:
        warnings.append("Challenging soil conditions — may need special foundations")
    if factors.get("access") and factors["access"].score < 30:
        warnings.append("Remote location — poor road access, higher construction logistics cost")
    return warnings


def generate_construction_verdict(
    construction: float,
    habitability: float,
    factors: Dict[str, FactorScore],
    terrain: Dict[str, Any],
    climate: Dict[str, Any],
    hard: List[str],
    lat: Optional[float] = None,
    lon: Optional[float] = None,
) -> ConstructionVerdict:
    """Generate a definitive, actionable verdict on construction suitability."""
    recs = []

    # Check for hard constraints first
    if hard:
        return ConstructionVerdict(
            status="unsuitable",
            badge="CRITICAL HAZARD — NOT RECOMMENDED",
            badge_color="#ef4444",
            verdict_title="Severe Natural Hazard — Construction Not Recommended",
            summary="Site exceeds critical physical safety thresholds (extreme unbuildable slope or extreme altitude). Permanent construction is hazardous.",
            recommendations=[
                "Avoid permanent commercial or residential construction at this pinpoint coordinate.",
                "Consider alternative low-risk building sites in surrounding flatter terrain.",
            ],
        )

    # Basin detection for authoritative flood verdict
    in_basin, b_name = (False, "")
    if lat is not None and lon is not None:
        in_basin, b_name = _is_major_flood_basin(lat, lon)

    # Flood-specific engineering recommendations
    flood_score = factors.get("flood", FactorScore(score=50, rating="Moderate")).score
    if flood_score < 40 or in_basin:
        recs.append("Construct strictly on reinforced concrete stilt / pile foundations (minimum 2.0m - 3.0m elevation above Highest Flood Level).")
        recs.append("Prohibit habitable basements and ground-floor residential occupancy; dedicate ground level to open stilts/parking.")
        recs.append("Mandatory hydrological site clearance and backflow check-valves on all stormwater/sewage lines.")
    elif flood_score < 60:
        recs.append("Elevate finished floor plinth level at least 0.75m–1.2m above surrounding ground level with perimeter French drains.")

    # Wind / Cyclone engineering recommendations
    max_wind = climate.get("max_wind_kmh") or (climate.get("avg_wind_kmh", 0) * 2.2)
    rain = climate.get("annual_rainfall_mm", 800)
    if max_wind >= 80 or (climate.get("storm_days_per_year", 0) > 3):
        recs.append("Design structural framing to resist high-velocity wind loads per IS 875 (Part 3) with continuous roof tie-down straps.")
        recs.append("Use aerodynamic hip roof designs with low eaves overhang; install impact-resistant storm shutters.")

    # Seismic recommendations
    seis_score = factors.get("seismic", FactorScore(score=50, rating="Moderate")).score
    if seis_score < 50:
        recs.append("Implement ductile earthquake-resistant RCC framing per IS 13920 / seismic code with shear walls.")

    # Slope recommendations
    slope_score = factors.get("slope", FactorScore(score=50, rating="Moderate")).score
    if slope_score < 45:
        recs.append("Install engineered reinforced retaining walls with weep holes and stepped foundation terracing.")

    # Soil recommendations
    soil_score = factors.get("soil", FactorScore(score=50, rating="Moderate")).score
    if soil_score < 45:
        recs.append("Perform site borehole SPT tests; expansive clay/loose alluvium requires under-reamed piles or raft foundation.")

    # Default recommendation if clean
    if not recs:
        recs.append("Standard isolated footings and RCC frame construction compliant with national building code are sufficient.")
        recs.append("Implement standard rainwater harvesting and municipal stormwater connection.")

    # Determine overall status and badge
    # Safety factors: flood, slope, seismic.
    # In active floodplains (Assam Brahmaputra, Kosi basin), trigger HIGH HAZARD regardless of moderate scores.
    if in_basin and flood_score < 45:
        return ConstructionVerdict(
            status="high_hazard",
            badge="HIGH HAZARD — SPECIAL ENGINEERING MANDATORY",
            badge_color="#f97316",
            verdict_title="Active River Floodplain Hazard Zone",
            summary=f"High seasonal flood hazard ({construction:.0f}% suitability). Situated in {b_name} with severe recurring monsoon inundation. Standard construction unsafe without elevated stilt foundations.",
            recommendations=recs,
        )

    if construction >= 78 and flood_score >= 42 and slope_score >= 50:
        return ConstructionVerdict(
            status="safe",
            badge="RECOMMENDED FOR CONSTRUCTION",
            badge_color="#22c55e",
            verdict_title="Land Highly Suitable for Construction",
            summary=f"High construction suitability ({construction:.0f}%). Stable geological footing and manageable environmental exposure. Standard construction approved with standard engineering practices.",
            recommendations=recs,
        )
    elif construction >= 60 and flood_score >= 30:
        return ConstructionVerdict(
            status="conditional",
            badge="CONDITIONAL — ENGINEERING MITIGATION REQUIRED",
            badge_color="#eab308",
            verdict_title="Construction Feasible with Specific Precautions",
            summary=f"Moderate construction suitability ({construction:.0f}%). Building is viable with engineered adaptations for identified local environmental factors.",
            recommendations=recs,
        )
    elif construction >= 35 or flood_score < 30:
        return ConstructionVerdict(
            status="high_hazard",
            badge="HIGH HAZARD — SPECIAL ENGINEERING MANDATORY",
            badge_color="#f97316",
            verdict_title="Elevated Environmental Hazard Zone",
            summary=f"High hazard exposure ({construction:.0f}% suitability). Site experiences significant environmental stress (active river floodplain, steep slopes, or high seismic activity). Standard construction is unsafe without specialized civil engineering.",
            recommendations=recs,
        )
    else:
        return ConstructionVerdict(
            status="unsuitable",
            badge="UNSUITABLE FOR STANDARD CONSTRUCTION",
            badge_color="#ef4444",
            verdict_title="Severe Hazard — Construction Not Advised",
            summary=f"Very low suitability ({construction:.0f}%). Location is situated in an active hazard zone. Commercial/residential development is strongly discouraged.",
            recommendations=recs,
        )


# ═══════════════════════════════════════════════════════════════════
# Full pipeline
# ═══════════════════════════════════════════════════════════════════

def build_assessment(
    lat: float,
    lon: float,
    terrain: Dict[str, Any],
    climate: Dict[str, Any],
    soil: Dict[str, Any],
    seismic: Dict[str, Any],
    infra: Dict[str, Any],
    land_cover: Optional[Dict[str, Any]] = None,
    flood_data: Optional[Dict[str, Any]] = None,
) -> AssessmentResult:
    """Assemble all factor scores into the final AssessmentResult."""

    # ── Score each factor ──
    factors: Dict[str, FactorScore] = {
        "slope":    score_slope(terrain),
        "elevation": score_elevation(terrain),
        "climate":  score_climate(climate),
        "soil":     score_soil(soil),
        "seismic":  score_seismic(seismic),
        "flood":    score_flood(terrain, climate, lat, lon, flood_data=flood_data),
        "access":   score_access(infra),
    }

    # ── Phase 6: land-cover factor (if Prithvi output exists) ──
    lc_factor = score_land_cover(land_cover)
    if lc_factor:
        factors["land_cover"] = lc_factor

    # ── Weighted scores ──
    construction = _weighted(factors, CONSTRUCTION_WEIGHTS)
    habitability = _weighted(factors, HABITABILITY_WEIGHTS)

    # ── Urban infrastructure correction ──────────────────────────────
    # Established metros with road networks demonstrate buildability;
    # however, DO NOT apply urban uplift if site has severe natural hazard
    # (e.g. active river floodplain in Assam or dangerous slope).
    nearest_road = infra.get("nearest_road_km", 15)
    road_count   = infra.get("road_count_nearby", 0)
    water_nearby = infra.get("water_supply_nearby", False)

    if nearest_road <= 0.3 and road_count >= 50:
        urban_tier = 3   # dense metro
    elif nearest_road <= 0.8 and road_count >= 20:
        urban_tier = 2   # urban
    elif nearest_road <= 2.0 and road_count >= 5:
        urban_tier = 1   # peri-urban
    else:
        urban_tier = 0   # rural / remote

    has_severe_hazard = (factors["flood"].score < 38) or (factors["slope"].score < 30)

    if not has_severe_hazard:
        if urban_tier == 3:
            construction = max(construction, construction * 1.0 + min(8, (90 - construction) * 0.35))
        elif urban_tier == 2:
            construction = max(construction, construction * 1.0 + min(5, (85 - construction) * 0.20))
        elif urban_tier == 1:
            construction = max(construction, construction * 1.0 + min(3, (80 - construction) * 0.10))

        if water_nearby and urban_tier >= 1:
            construction = min(100, construction + 1.5)

    construction = round(min(construction, 100), 1)
    habitability = round(habitability, 1)
    overall = round(construction * 0.55 + habitability * 0.45, 1)

    # ── Hard constraints & warnings ──
    hard = check_hard_constraints(terrain, climate)
    warns = generate_warnings(factors, terrain, climate, seismic)

    # Add flood basin warning if applicable
    in_basin, b_name = _is_major_flood_basin(lat, lon)
    if in_basin and factors["flood"].score < 45:
        warns.insert(0, f"Critical Flood Plain: {b_name} — seasonal monsoon inundation risk")

    # Penalise scores for hard constraints
    if hard:
        construction = round(min(construction, 20), 1)
        overall = round(min(overall, 25), 1)

    # ── Comprehensive Construction Verdict ──
    verdict = generate_construction_verdict(
        construction, habitability, factors, terrain, climate, hard, lat=lat, lon=lon
    )

    return AssessmentResult(
        coordinates=Coordinates(lat=lat, lon=lon),
        construction_score=construction,
        habitability_score=habitability,
        overall_score=overall,
        verdict=verdict,
        factors=factors,
        terrain=TerrainDetail(
            center_elevation_m=terrain.get("center_elevation"),
            mean_elevation_m=terrain.get("mean_elevation"),
            max_slope_pct=terrain.get("max_slope_pct"),
            mean_slope_pct=terrain.get("mean_slope_pct"),
        ),
        climate=ClimateDetail(
            avg_temp_c=climate.get("avg_temp_c"),
            max_temp_c=climate.get("max_temp_c"),
            min_temp_c=climate.get("min_temp_c"),
            avg_humidity_pct=climate.get("avg_humidity_pct"),
            annual_rainfall_mm=climate.get("annual_rainfall_mm"),
            hot_days_per_year=climate.get("hot_days_per_year"),
            cold_days_per_year=climate.get("cold_days_per_year"),
            heavy_rain_days_per_year=climate.get("heavy_rain_days_per_year"),
            avg_wind_kmh=climate.get("avg_wind_kmh"),
            max_wind_kmh=climate.get("max_wind_kmh"),
            storm_days_per_year=climate.get("storm_days_per_year"),
            river_discharge_m3s=flood_data.get("river_discharge_m3s") if flood_data else None,
        ),
        soil=SoilDetail(
            clay_pct=soil.get("clay_pct"),
            sand_pct=soil.get("sand_pct"),
            silt_pct=soil.get("silt_pct"),
            organic_carbon=soil.get("organic_carbon_g_per_kg"),
            ph=soil.get("ph"),
        ),
        seismic=SeismicDetail(
            earthquake_count=seismic.get("earthquake_count", 0),
            max_magnitude=seismic.get("max_magnitude"),
            nearest_km=seismic.get("nearest_km"),
            search_radius_km=seismic.get("search_radius_km", 200),
        ),
        access=AccessDetail(
            road_count_nearby=infra.get("road_count_nearby", 0),
            nearest_road_km=infra.get("nearest_road_km"),
            water_supply_nearby=infra.get("water_supply_nearby", False),
        ),
        land_cover=LandCoverDetail(**land_cover) if land_cover else None,
        warnings=warns,
        hard_constraints=hard,
    )
