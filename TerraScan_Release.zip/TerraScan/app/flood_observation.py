"""Query an operator-provided georeferenced binary water mask."""
import json
import logging
import os
from datetime import date
from pathlib import Path

LOG = logging.getLogger(__name__)


def observe_water(lat: float, lon: float) -> dict:
    root = os.getenv("TERRASCAN_FLOOD_OBSERVATION_DIR")
    if not root:
        return {"status": "unavailable"}

    try:
        import numpy as np
        import rasterio
        from rasterio.warp import transform

        directory = Path(root)
        metadata = json.loads((directory / "observation.json").read_text(encoding="utf-8"))
        acquired = date.fromisoformat(metadata["acquired_on"])
        source = metadata["source"]
        if not isinstance(source, str) or not source.strip():
            raise ValueError("Missing observation source")
        with rasterio.open(directory / "water.tif") as mask:
            if mask.count != 1 or mask.crs is None:
                raise ValueError("Expected a georeferenced single-band water mask")
            x, y = transform("EPSG:4326", mask.crs, [lon], [lat])
            row, col = mask.index(x[0], y[0])
            if not (0 <= row < mask.height and 0 <= col < mask.width):
                return {"status": "outside_coverage"}
            value = mask.read(1, window=((row, row + 1), (col, col + 1)), masked=True)[0, 0]
            if np.ma.is_masked(value) or value not in (0, 1):
                return {"status": "no_valid_pixel"}
        return {"status": "available", "water_detected": bool(value),
                "acquired_on": acquired.isoformat(), "source": source}
    except (ImportError, OSError, ValueError, KeyError, TypeError) as error:
        LOG.warning("Flood observation unavailable: %s", type(error).__name__)
        return {"status": "unavailable"}
