"""
FastAPI application – Land Suitability Assessment Engine
Serves both the API and the frontend.
"""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from fastapi import FastAPI, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

from app.data_fetch import (
    get_elevation_grid,
    get_climate_data,
    get_soil_data,
    get_seismic_data,
    get_infrastructure_data,
    get_flood_data,
)
from app.scoring import build_assessment
from app.imagery import load_prithvi_features
from app.flood_observation import observe_water
from app.models import AssessmentResult
from app.calamity_predict import predict_all_calamities
from app.history_fetch import get_disaster_history, compute_history_adjustments


# ── App setup ──────────────────────────────────────────────────────

app = FastAPI(
    title="Land Suitability Assessment Engine",
    description="Evaluate any coordinate on Earth for construction suitability and habitability.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve frontend
app.mount("/static", StaticFiles(directory="static"), name="static")


# ── Endpoints ──────────────────────────────────────────────────────

@app.get("/", include_in_schema=False)
async def root():
    return FileResponse("static/index.html")


@app.get("/api/health")
async def health():
    return {"status": "ok", "engine": "Land Suitability Assessment v1.0"}


@app.get("/api/flood-observation")
def flood_observation(
    lat: float = Query(..., ge=-90, le=90),
    lon: float = Query(..., ge=-180, le=180),
):
    return observe_water(lat, lon)


@app.get("/api/score", response_model=AssessmentResult)
async def score(
    lat: float = Query(..., ge=-90, le=90, description="Latitude"),
    lon: float = Query(..., ge=-180, le=180, description="Longitude"),
):
    """
    Main endpoint.  Fetches terrain, climate, soil, seismic, and
    infrastructure data in parallel, scores each factor, and returns
    a combined construction + habitability assessment.
    """
    t0 = time.time()

    # ── Fetch all data concurrently ──
    results = {}
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = {
            pool.submit(get_elevation_grid, lat, lon): "terrain",
            pool.submit(get_climate_data,   lat, lon): "climate",
            pool.submit(get_soil_data,      lat, lon): "soil",
            pool.submit(get_seismic_data,   lat, lon): "seismic",
            pool.submit(get_infrastructure_data, lat, lon): "infra",
            pool.submit(get_flood_data,     lat, lon): "flood_data",
        }
        for future in as_completed(futures):
            key = futures[future]
            try:
                results[key] = future.result()
            except Exception as exc:
                results[key] = {"error": str(exc)}

    terrain    = results.get("terrain", {})
    climate    = results.get("climate", {})
    soil       = results.get("soil",    {})
    seismic    = results.get("seismic", {})
    infra      = results.get("infra",   {})
    flood_data = results.get("flood_data", {})

    # Attach river discharge to climate if present
    if flood_data.get("river_discharge_m3s") is not None:
        climate["river_discharge_m3s"] = flood_data["river_discharge_m3s"]

    # ── Phase 6: check for Prithvi outputs ──
    land_cover = load_prithvi_features(lat, lon)

    # ── Build assessment ──
    assessment = build_assessment(
        lat, lon, terrain, climate, soil, seismic, infra, land_cover, flood_data=flood_data
    )

    elapsed = round(time.time() - t0, 2)
    return assessment


@app.get("/api/calamity")
async def calamity(
    lat: float = Query(..., ge=-90, le=90, description="Latitude"),
    lon: float = Query(..., ge=-180, le=180, description="Longitude"),
):
    """
    Natural calamity risk prediction endpoint.
    Analyses earthquake, flood, cyclone, landslide, drought, wildfire,
    tsunami, and volcanic risk for a given location.
    History data and real-time flood hydrology are fetched concurrently.
    """
    t0 = time.time()

    # ── Fetch terrain, climate, seismic, flood data AND history concurrently ──
    results = {}
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {
            pool.submit(get_elevation_grid, lat, lon): "terrain",
            pool.submit(get_climate_data,   lat, lon): "climate",
            pool.submit(get_seismic_data,   lat, lon): "seismic",
            pool.submit(get_flood_data,     lat, lon): "flood_data",
            pool.submit(get_disaster_history, lat, lon): "history",
        }
        for future in as_completed(futures):
            key = futures[future]
            try:
                results[key] = future.result()
            except Exception as exc:
                results[key] = {"error": str(exc)}

    terrain    = results.get("terrain", {})
    climate    = results.get("climate", {})
    seismic    = results.get("seismic", {})
    flood_data = results.get("flood_data", {})
    history    = results.get("history", {})

    # Attach river discharge to climate if present
    if flood_data.get("river_discharge_m3s") is not None:
        climate["river_discharge_m3s"] = flood_data["river_discharge_m3s"]

    # ── Compute history-based adjustments ──
    frequency_map = history.get("frequency_map", {})
    history_adjustments = compute_history_adjustments(frequency_map)

    # ── Run all calamity predictors ──
    report = predict_all_calamities(
        lat, lon, terrain, climate, seismic,
        history_adjustments=history_adjustments,
        flood_data=flood_data,
    )
    report["coordinates"]     = {"lat": lat, "lon": lon}
    report["elapsed_seconds"] = round(time.time() - t0, 2)
    report["history_summary"] = {
        "total_events":  history.get("total_events", 0),
        "most_frequent": history.get("most_frequent"),
        "earliest_year": history.get("earliest_year"),
        "sources_used":  history.get("sources_used", []),
        "type_counts":   history.get("type_counts", {}),
    }

    return report


@app.get("/api/history")
async def history_endpoint(
    lat: float = Query(..., ge=-90, le=90,   description="Latitude"),
    lon: float = Query(..., ge=-180, le=180, description="Longitude"),
):
    """
    Historical disaster events endpoint.
    Returns real past calamity events from USGS, NASA EONET, GDACS, and
    ReliefWeb within 300 km of the given coordinates.
    Includes per-type event counts, decade breakdown, and severity stats.
    """
    t0 = time.time()
    data = get_disaster_history(lat, lon)
    data["coordinates"]     = {"lat": lat, "lon": lon}
    data["elapsed_seconds"] = round(time.time() - t0, 2)
    return data


# ── Run with: uvicorn app.main:app --reload ────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
