"""Check points against Natural Earth land polygons."""
import os
from functools import lru_cache
from io import BytesIO
from zipfile import ZipFile


@lru_cache(maxsize=1)
def land_index():
    import shapefile
    from shapely.geometry import shape
    from shapely.strtree import STRtree

    path = os.getenv("TERRASCAN_LAND_MASK", "data/ne_10m_land.zip")
    with ZipFile(path) as dataset:
        with shapefile.Reader(shp=BytesIO(dataset.read("ne_10m_land.shp"))) as reader:
            polygons = [shape(item.__geo_interface__) for item in reader.iterShapes()]
    if not polygons:
        raise ValueError("Empty land dataset")
    return STRtree(polygons)


def is_on_land(lat: float, lon: float) -> bool:
    from shapely.geometry import Point

    return bool(len(land_index().query(Point(lon, lat), predicate="covered_by")))
