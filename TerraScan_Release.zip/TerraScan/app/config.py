"""
Configuration constants for the Land Suitability Assessment Engine.
All API endpoints, scoring weights, and thresholds live here.
"""

# ── API Endpoints (all free, no keys needed) ───────────────────────
ELEVATION_API = "https://api.open-meteo.com/v1/elevation"
CLIMATE_ARCHIVE_API = "https://archive-api.open-meteo.com/v1/archive"
SOILGRIDS_API = "https://rest.isric.org/soilgrids/v2.0/properties/query"
USGS_EARTHQUAKE_API = "https://earthquake.usgs.gov/fdsnws/event/1/query"
OVERPASS_API = "https://overpass-api.de/api/interpreter"
FLOOD_API = "https://flood-api.open-meteo.com/v1/flood"

# ── Request settings ───────────────────────────────────────────────
REQUEST_TIMEOUT = 20          # seconds per API call
CLIMATE_YEARS = 5             # years of historical data to average
CLIMATE_END_YEAR = 2024
CLIMATE_START_YEAR = CLIMATE_END_YEAR - CLIMATE_YEARS

# ── Elevation / slope grid ─────────────────────────────────────────
GRID_SIZE = 5                 # 5×5 = 25 sample points
GRID_SPACING_M = 30.0         # ~30 m between points (≈1 SRTM pixel)

# ── Seismic search parameters ─────────────────────────────────────
SEISMIC_RADIUS_KM = 200
SEISMIC_MIN_MAG = 4.0
SEISMIC_YEARS = 50

# ── OSM / infrastructure search radius ─────────────────────────────
OSM_SEARCH_RADIUS_M = 5000    # 5 km

# ── Construction score weights (must sum to 1.0) ───────────────────
# Access weight raised: well-connected cities (roads, water) are genuinely
# more buildable. Flood weight trimmed: mitigable with engineering.
CONSTRUCTION_WEIGHTS = {
    "slope":    0.28,
    "elevation": 0.10,
    "soil":     0.20,
    "seismic":  0.14,
    "flood":    0.13,
    "access":   0.15,
}

# ── Habitability score weights (must sum to 1.0) ───────────────────
HABITABILITY_WEIGHTS = {
    "climate":   0.40,
    "access":    0.20,
    "flood":     0.15,
    "seismic":   0.15,
    "elevation": 0.10,
}

# ── Slope breakpoints  (slope_%, score) ────────────────────────────
SLOPE_BREAKPOINTS = [
    (0,  100),
    (2,   95),
    (5,   85),
    (10,  65),
    (15,  45),
    (25,  20),
    (35,   5),
    (50,   0),
]

# ── Elevation breakpoints (meters, score) ──────────────────────────
ELEVATION_BREAKPOINTS = [
    (0,    90),   # sea-level – slight flood concern
    (100, 100),
    (500,  95),
    (1000, 80),
    (2000, 55),
    (3000, 30),
    (4500, 10),
]

# ── Temperature comfort (°C mean, score) ───────────────────────────
TEMP_BREAKPOINTS = [
    (-20,  0),
    (-5,  20),
    (5,   50),
    (15,  85),
    (20, 100),
    (25, 100),
    (30,  75),
    (35,  40),
    (45,   5),
]

# ── Humidity comfort (%, score) ────────────────────────────────────
HUMIDITY_BREAKPOINTS = [
    (10,  40),
    (25,  80),
    (40, 100),
    (60, 100),
    (75,  65),
    (85,  35),
    (95,  10),
]

# ── Annual rainfall (mm, score) ────────────────────────────────────
# Recalibrated: tropical Indian cities (1000-1500mm/yr) are well-adapted
# to their rainfall patterns; this should not drag construction scores.
RAINFALL_BREAKPOINTS = [
    (0,    10),
    (200,  45),
    (600,  85),
    (1000, 100),
    (1800,  92),
    (2500,  70),
    (3500,  40),
    (5000,  15),
]

# ── Soil clay content (%, score) – for construction ────────────────
CLAY_BREAKPOINTS = [
    (0,   75),   # pure sand, ok drainage but poor bearing
    (10,  88),
    (20, 100),   # ideal mix
    (30,  92),   # clay loam (standard construction soil)
    (40,  82),   # cohesive soil (standard RCC footings)
    (50,  55),   # high clay, requires swell check
    (65,  25),   # expansive black cotton clay
    (80,  10),
]

# ── Seismic event count → score ────────────────────────────────────
# Recalibrated: moderate seismicity (10-30 events in 200km/50yr) is normal
# for peninsular India and should not severely penalise stable metros.
SEISMIC_BREAKPOINTS = [
    (0,   100),
    (5,    92),
    (15,   78),
    (40,   55),
    (80,   30),
    (150,   8),
]

# ── Road proximity (km → score) ───────────────────────────────────
ACCESS_BREAKPOINTS = [
    (0,   100),
    (0.5, 100),
    (2,    80),
    (5,    55),
    (10,   30),
    (20,   10),
    (50,    0),
]

# ── Hard-constraint thresholds ─────────────────────────────────────
HARD_SLOPE_LIMIT = 45          # % – effectively unbuildable
HARD_ELEVATION_LIMIT = 4000    # m – extreme altitude
HARD_FLOOD_DISCHARGE = 500     # m³/s – severe flood risk

# ── Imagery / Prithvi (Phase 5-6) ─────────────────────────────────
PRITHVI_FEATURES_DIR = "prithvi_features"   # folder for saved outputs
