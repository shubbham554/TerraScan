"""
History Fetch Module — Natural Disaster Historical Events
=========================================================
Retrieves REAL historical calamity events from multiple free APIs:

  1. USGS Earthquake Catalog  → M4+ earthquakes (all time)
  2. NASA EONET API           → Wildfires, Volcanoes, Storms, Floods, Drought
  3. GDACS API                → Floods, Cyclones, Earthquakes, Volcanoes, Drought
  4. ReliefWeb API            → Disaster situation reports (last 20 years)

The combined history is used to:
  - Display a "Disaster Timeline" tab in the frontend
  - Recalibrate calamity risk predictions based on ACTUAL event frequency
"""

import math
import requests
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

from app.config import REQUEST_TIMEOUT


# ═══════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════

HISTORY_RADIUS_KM   = 300    # search radius for historical events
HISTORY_YEARS       = 50     # how far back to look (where APIs allow)
EONET_DAYS          = 3650   # ~10 years for NASA EONET
GDACS_RADIUS_DEG    = 2.5    # ~275 km bounding box half-width in degrees

# Calamity type normalisation map
_TYPE_MAP = {
    # USGS / seismic
    "earthquake": "earthquake",
    # NASA EONET categories
    "wildfires":        "wildfire",
    "volcanoes":        "volcanic",
    "severeStorms":     "cyclone",
    "floods":           "flood",
    "drought":          "drought",
    "seaLakeIce":       "other",
    "snow":             "other",
    "tempExtremes":     "other",
    # GDACS event types
    "EQ": "earthquake",
    "TC": "cyclone",
    "FL": "flood",
    "VO": "volcanic",
    "DR": "drought",
    "TS": "tsunami",
    "WF": "wildfire",
}

EMOJI_MAP = {
    "earthquake": "🌍",
    "flood":      "🌊",
    "cyclone":    "🌀",
    "wildfire":   "🔥",
    "volcanic":   "🌋",
    "drought":    "☀️",
    "tsunami":    "🌊",
    "landslide":  "⛰️",
    "other":      "⚡",
}

SEVERITY_COLORS = {
    "extreme":    "#ef4444",
    "severe":     "#f97316",
    "moderate":   "#eab308",
    "minor":      "#84cc16",
    "unknown":    "#6b7280",
}


# ═══════════════════════════════════════════════════════════════════
# Utility helpers
# ═══════════════════════════════════════════════════════════════════

def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km."""
    R = 6371.0
    φ1, φ2 = math.radians(lat1), math.radians(lat2)
    Δφ = math.radians(lat2 - lat1)
    Δλ = math.radians(lon2 - lon1)
    a = math.sin(Δφ / 2) ** 2 + math.cos(φ1) * math.cos(φ2) * math.sin(Δλ / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _normalise_type(raw: str) -> str:
    return _TYPE_MAP.get(raw, "other")


def _severity_from_magnitude(mag: Optional[float]) -> str:
    if mag is None:
        return "unknown"
    if mag >= 7.0:
        return "extreme"
    if mag >= 6.0:
        return "severe"
    if mag >= 5.0:
        return "moderate"
    return "minor"


def _severity_from_alert(alert: Optional[str]) -> str:
    alert = (alert or "").lower()
    return {"red": "extreme", "orange": "severe", "yellow": "moderate", "green": "minor"}.get(alert, "unknown")


def _fmt_date(iso: Optional[str]) -> str:
    """Return 'YYYY-MM-DD' or 'Unknown date'."""
    if not iso:
        return "Unknown date"
    try:
        return iso[:10]
    except Exception:
        return str(iso)[:10]


# ═══════════════════════════════════════════════════════════════════
# Source 1 — USGS Earthquake Catalog (all-time M4+)
# ═══════════════════════════════════════════════════════════════════

def _fetch_usgs_history(lat: float, lon: float) -> List[Dict]:
    """
    Fetch ALL recorded M4+ earthquakes within HISTORY_RADIUS_KM.
    Uses the USGS FDSN event query with no start date (goes back to ~1970s).
    """
    events = []
    try:
        resp = requests.get(
            "https://earthquake.usgs.gov/fdsnws/event/1/query",
            params={
                "format":        "geojson",
                "latitude":      lat,
                "longitude":     lon,
                "maxradiuskm":   HISTORY_RADIUS_KM,
                "minmagnitude":  4.0,
                "orderby":       "time",
                "limit":         200,
            },
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        features = resp.json().get("features", [])
    except Exception as exc:
        return [{"_error": f"USGS fetch failed: {exc}"}]

    for f in features:
        props = f.get("properties", {})
        geom  = f.get("geometry", {}).get("coordinates", [])
        mag   = props.get("mag")
        ts    = props.get("time")  # epoch ms
        date  = datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime("%Y-%m-%d") if ts else "Unknown"
        dist  = _haversine(lat, lon, geom[1], geom[0]) if len(geom) >= 2 else None
        place = props.get("place", "Unknown location")

        events.append({
            "type":     "earthquake",
            "emoji":    "🌍",
            "date":     date,
            "year":     int(date[:4]) if date != "Unknown" else None,
            "title":    f"M{mag} Earthquake — {place}",
            "severity": _severity_from_magnitude(mag),
            "magnitude": mag,
            "distance_km": round(dist, 1) if dist else None,
            "source":   "USGS Earthquake Catalog",
            "detail":   f"Magnitude {mag} at {place}" + (f", ~{round(dist)}km away" if dist else ""),
        })

    return events


# ═══════════════════════════════════════════════════════════════════
# Source 2 — NASA EONET (Earth Observatory Natural Event Tracker)
# ═══════════════════════════════════════════════════════════════════

def _fetch_eonet_history(lat: float, lon: float) -> List[Dict]:
    """
    Fetch natural events (wildfires, storms, volcanoes, floods) from NASA EONET.
    Filters spatially by checking event geometry within HISTORY_RADIUS_KM.
    """
    events = []
    bbox_deg = HISTORY_RADIUS_KM / 111.0
    min_lat = lat - bbox_deg
    max_lat = lat + bbox_deg
    min_lon = lon - bbox_deg
    max_lon = lon + bbox_deg

    try:
        resp = requests.get(
            "https://eonet.gsfc.nasa.gov/api/v3/events",
            params={
                "status": "all",
                "days":   EONET_DAYS,
                "bbox":   f"{min_lon},{min_lat},{max_lon},{max_lat}",
                "limit":  200,
            },
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        raw_events = resp.json().get("events", [])
    except Exception as exc:
        return [{"_error": f"EONET fetch failed: {exc}"}]

    for ev in raw_events:
        categories = ev.get("categories", [])
        cat_id     = categories[0].get("id", "other") if categories else "other"
        ev_type    = _normalise_type(cat_id)

        geometries = ev.get("geometry", [])
        if not geometries:
            continue

        # Use first geometry point
        geom0  = geometries[0]
        coords = geom0.get("coordinates", [])
        date   = geom0.get("date", "")

        if len(coords) >= 2:
            ev_lon, ev_lat = coords[0], coords[1]
            dist = _haversine(lat, lon, ev_lat, ev_lon)
            if dist > HISTORY_RADIUS_KM:
                continue
        else:
            dist = None

        date_str = _fmt_date(date)
        year     = int(date_str[:4]) if date_str and date_str != "Unknown date" else None
        title    = ev.get("title", "Natural Event")

        events.append({
            "type":        ev_type,
            "emoji":       EMOJI_MAP.get(ev_type, "⚡"),
            "date":        date_str,
            "year":        year,
            "title":       title,
            "severity":    "moderate",   # EONET doesn't provide severity
            "distance_km": round(dist, 1) if dist else None,
            "source":      "NASA EONET",
            "detail":      f"{title}" + (f" — ~{round(dist)}km from query point" if dist else ""),
        })

    return events


# ═══════════════════════════════════════════════════════════════════
# Source 3 — GDACS (Global Disaster Alert and Coordination System)
# ═══════════════════════════════════════════════════════════════════

def _fetch_gdacs_history(lat: float, lon: float) -> List[Dict]:
    """
    Fetch recent global disaster events from GDACS within a bounding box.
    GDACS covers: Earthquakes (EQ), Tropical Cyclones (TC), Floods (FL),
    Volcanoes (VO), Drought (DR), Tsunami (TS).
    """
    events = []
    today  = datetime.utcnow()
    from_date = f"{today.year - 20}-01-01"   # last 20 years
    to_date   = today.strftime("%Y-%m-%d")

    # Bounding box
    bbox = (
        f"{lon - GDACS_RADIUS_DEG},{lat - GDACS_RADIUS_DEG},"
        f"{lon + GDACS_RADIUS_DEG},{lat + GDACS_RADIUS_DEG}"
    )

    try:
        resp = requests.get(
            "https://www.gdacs.org/gdacsapi/api/events/geteventlist/MAP",
            params={
                "eventtypes": "EQ,TC,FL,VO,DR,TS",
                "fromDate":   from_date,
                "toDate":     to_date,
                "bbox":       bbox,
            },
            timeout=REQUEST_TIMEOUT,
            headers={"Accept": "application/json"},
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        return [{"_error": f"GDACS fetch failed: {exc}"}]

    features = data.get("features", [])
    for f in features:
        props  = f.get("properties", {})
        geom   = f.get("geometry", {}).get("coordinates", [])
        ev_type = _normalise_type(props.get("eventtype", "other"))

        # Spatial filter
        if len(geom) >= 2:
            dist = _haversine(lat, lon, geom[1], geom[0])
            if dist > HISTORY_RADIUS_KM:
                continue
        else:
            dist = None

        alert_level = props.get("alertlevel", "")
        severity    = _severity_from_alert(alert_level)
        date_str    = _fmt_date(props.get("fromdate") or props.get("todate", ""))
        year        = int(date_str[:4]) if date_str and date_str != "Unknown date" else None
        name        = props.get("name", props.get("eventname", "Disaster event"))
        country     = props.get("country", "")
        deaths      = props.get("iscalc", {})
        affected    = props.get("population", {})

        detail_parts = [name]
        if country:
            detail_parts.append(country)
        if deaths and isinstance(deaths, dict):
            d = deaths.get("deaths", 0)
            if d:
                detail_parts.append(f"{int(d)} deaths")
        if dist:
            detail_parts.append(f"~{round(dist)}km away")

        events.append({
            "type":        ev_type,
            "emoji":       EMOJI_MAP.get(ev_type, "⚡"),
            "date":        date_str,
            "year":        year,
            "title":       name,
            "severity":    severity,
            "alert_level": alert_level.lower() if alert_level else "unknown",
            "distance_km": round(dist, 1) if dist else None,
            "source":      "GDACS",
            "detail":      " · ".join(detail_parts),
        })

    return events


# ═══════════════════════════════════════════════════════════════════
# Source 4 — ReliefWeb Disaster Database
# ═══════════════════════════════════════════════════════════════════

def _fetch_reliefweb_history(lat: float, lon: float) -> List[Dict]:
    """
    Query ReliefWeb API for disaster reports near the given coordinates.
    Uses country-level proximity based on bounding box reverse geocoding.
    """
    events = []

    # First resolve the country name from lat/lon via Nominatim
    country_code = None
    try:
        geo_resp = requests.get(
            "https://nominatim.openstreetmap.org/reverse",
            params={"lat": lat, "lon": lon, "format": "json"},
            headers={"User-Agent": "TerraScan/1.0"},
            timeout=10,
        )
        if geo_resp.ok:
            addr = geo_resp.json().get("address", {})
            country_code = addr.get("country_code", "").upper()
    except Exception:
        pass

    if not country_code:
        return []

    # Query ReliefWeb disasters for this country
    try:
        payload = {
            "filter": {
                "operator": "AND",
                "conditions": [
                    {"field": "country.iso3", "value": country_code},
                ],
            },
            "fields": {"include": ["name", "date", "type", "status", "country", "glide"]},
            "sort": ["date:desc"],
            "limit": 50,
        }
        resp = requests.post(
            "https://api.reliefweb.int/v1/disasters",
            json=payload,
            timeout=REQUEST_TIMEOUT,
            headers={"Accept": "application/json"},
        )
        resp.raise_for_status()
        items = resp.json().get("data", [])
    except Exception as exc:
        return [{"_error": f"ReliefWeb fetch failed: {exc}"}]

    for item in items:
        fields  = item.get("fields", {})
        name    = fields.get("name", "Disaster")
        date_str = _fmt_date(fields.get("date", {}).get("event") if isinstance(fields.get("date"), dict) else fields.get("date"))
        year     = int(date_str[:4]) if date_str and date_str != "Unknown date" else None

        types = fields.get("type", [])
        raw_type = types[0].get("name", "other").lower() if types else "other"

        # Map ReliefWeb types
        type_map = {
            "earthquake":        "earthquake",
            "flood":             "flood",
            "tropical cyclone":  "cyclone",
            "storm":             "cyclone",
            "drought":           "drought",
            "wildfire":          "wildfire",
            "volcanic eruption": "volcanic",
            "tsunami":           "tsunami",
            "landslide":         "landslide",
            "epidemic":          "other",
            "conflict":          "other",
        }
        ev_type = "other"
        for key, val in type_map.items():
            if key in raw_type:
                ev_type = val
                break

        if ev_type == "other":
            continue   # Skip non-natural-disaster items

        events.append({
            "type":        ev_type,
            "emoji":       EMOJI_MAP.get(ev_type, "⚡"),
            "date":        date_str,
            "year":        year,
            "title":       name,
            "severity":    "moderate",   # ReliefWeb doesn't expose severity easily
            "distance_km": None,         # country-level, not point
            "source":      "ReliefWeb",
            "detail":      name + (f" ({country_code})" if country_code else ""),
            "country_code": country_code,
        })

    return events


# ═══════════════════════════════════════════════════════════════════
# Master history aggregator
# ═══════════════════════════════════════════════════════════════════

def get_disaster_history(lat: float, lon: float) -> Dict[str, Any]:
    """
    Fetch and merge historical disaster events from all sources.
    Returns:
      - events         : sorted list of historical events (newest first)
      - type_counts    : { calamity_type: count }
      - decade_counts  : { decade_label: count }
      - frequency_map  : { calamity_type: events_per_decade } for recalibration
      - sources_used   : list of data sources that responded
      - total_events   : total distinct events found
      - most_frequent  : most common disaster type
      - earliest_year  : oldest recorded event year
    """
    all_events: List[Dict] = []
    sources_used: List[str] = []
    errors: List[str] = []

    # ── Parallel-ish fetch (sequential for simplicity; each has own timeout) ──
    for fetcher, label in [
        (_fetch_usgs_history,      "USGS Earthquake Catalog"),
        (_fetch_eonet_history,     "NASA EONET"),
        (_fetch_gdacs_history,     "GDACS"),
        (_fetch_reliefweb_history, "ReliefWeb"),
    ]:
        try:
            results = fetcher(lat, lon)
            # Filter out error sentinel dicts
            clean = [e for e in results if "_error" not in e]
            errs  = [e["_error"] for e in results if "_error" in e]
            errors.extend(errs)
            if clean:
                all_events.extend(clean)
                sources_used.append(label)
        except Exception as e:
            errors.append(f"{label}: {e}")

    # ── De-duplicate: same type + same date + similar name ──
    seen = set()
    deduped = []
    for ev in all_events:
        key = (ev.get("type"), ev.get("date", "")[:7], ev.get("title", "")[:30])
        if key not in seen:
            seen.add(key)
            deduped.append(ev)

    # ── Sort: newest first ──
    def _sort_key(ev):
        d = ev.get("date", "0000-00-00")
        return d if d != "Unknown date" else "0000-00-00"

    deduped.sort(key=_sort_key, reverse=True)

    # ── Type counts ──
    type_counts: Dict[str, int] = {}
    for ev in deduped:
        t = ev.get("type", "other")
        type_counts[t] = type_counts.get(t, 0) + 1

    # ── Decade counts ──
    decade_counts: Dict[str, int] = {}
    for ev in deduped:
        year = ev.get("year")
        if year:
            decade = f"{(year // 10) * 10}s"
            decade_counts[decade] = decade_counts.get(decade, 0) + 1

    # ── Frequency map (events per decade, for calamity recalibration) ──
    # Find span of data
    years = [ev["year"] for ev in deduped if ev.get("year")]
    earliest_year = min(years) if years else None
    latest_year   = max(years) if years else datetime.utcnow().year
    span_decades  = max(1, (latest_year - (earliest_year or latest_year - 10)) / 10)

    frequency_map: Dict[str, float] = {}
    for t, cnt in type_counts.items():
        frequency_map[t] = round(cnt / span_decades, 2)   # events per decade

    # Most frequent disaster type
    most_frequent = max(type_counts, key=type_counts.get) if type_counts else None

    # ── Severity breakdown ──
    severity_counts = {"extreme": 0, "severe": 0, "moderate": 0, "minor": 0, "unknown": 0}
    for ev in deduped:
        sev = ev.get("severity", "unknown")
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    return {
        "events":        deduped[:100],     # cap at 100 for UI performance
        "total_events":  len(deduped),
        "type_counts":   type_counts,
        "decade_counts": decade_counts,
        "severity_counts": severity_counts,
        "frequency_map": frequency_map,
        "most_frequent": most_frequent,
        "earliest_year": earliest_year,
        "sources_used":  sources_used,
        "fetch_errors":  errors,
        "search_radius_km": HISTORY_RADIUS_KM,
    }


# ═══════════════════════════════════════════════════════════════════
# Recalibration helper (used by calamity_predict)
# ═══════════════════════════════════════════════════════════════════

def compute_history_adjustments(frequency_map: Dict[str, float]) -> Dict[str, float]:
    """
    Convert frequency_map (events/decade) into risk score adjustment factors.
    Returns additive boosts (+) or reductions (-) to raw risk scores.

    Logic:
      - If a type has HIGH historical frequency → boost risk score (up to +15)
      - If a type has ZERO history in a data-rich region → modest reduction (-5)
    """
    adjustments: Dict[str, float] = {}
    for calamity_type in ["earthquake", "flood", "cyclone", "wildfire",
                           "volcanic", "drought", "tsunami", "landslide"]:
        freq = frequency_map.get(calamity_type, 0)
        if freq >= 5:          # ≥5 events/decade → significant history
            adjustments[calamity_type] = min(15.0, freq * 1.5)
        elif freq >= 2:        # 2-5/decade → moderate uplift
            adjustments[calamity_type] = freq * 1.0
        elif freq >= 0.5:      # occasional
            adjustments[calamity_type] = freq * 0.5
        else:                  # very rare or absent
            adjustments[calamity_type] = 0.0

    return adjustments

