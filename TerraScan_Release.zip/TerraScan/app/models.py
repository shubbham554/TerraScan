"""
Pydantic response models for the Land Suitability API.
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict


class Coordinates(BaseModel):
    lat: float = Field(..., ge=-90, le=90)
    lon: float = Field(..., ge=-180, le=180)


class FactorScore(BaseModel):
    """One scored dimension (slope, climate, soil, etc.)."""
    value: Optional[float] = Field(None, description="Raw measured value")
    unit: str = ""
    score: float = Field(..., ge=0, le=100)
    rating: str = Field(..., description="Excellent / Good / Moderate / Fair / Poor")
    detail: Optional[str] = None


class ClimateDetail(BaseModel):
    avg_temp_c: Optional[float] = None
    max_temp_c: Optional[float] = None
    min_temp_c: Optional[float] = None
    avg_humidity_pct: Optional[float] = None
    annual_rainfall_mm: Optional[float] = None
    hot_days_per_year: Optional[float] = None
    cold_days_per_year: Optional[float] = None
    heavy_rain_days_per_year: Optional[float] = None
    avg_wind_kmh: Optional[float] = None
    max_wind_kmh: Optional[float] = None
    storm_days_per_year: Optional[float] = None
    river_discharge_m3s: Optional[float] = None


class SoilDetail(BaseModel):
    clay_pct: Optional[float] = None
    sand_pct: Optional[float] = None
    silt_pct: Optional[float] = None
    organic_carbon: Optional[float] = None
    ph: Optional[float] = None


class TerrainDetail(BaseModel):
    center_elevation_m: Optional[float] = None
    mean_elevation_m: Optional[float] = None
    max_slope_pct: Optional[float] = None
    mean_slope_pct: Optional[float] = None


class SeismicDetail(BaseModel):
    earthquake_count: int = 0
    max_magnitude: Optional[float] = None
    nearest_km: Optional[float] = None
    search_radius_km: float = 200


class AccessDetail(BaseModel):
    road_count_nearby: int = 0
    nearest_road_km: Optional[float] = None
    water_supply_nearby: bool = False


class LandCoverDetail(BaseModel):
    """Phase 6 – from Prithvi imagery."""
    dominant_class: Optional[str] = None
    vegetation_pct: Optional[float] = None
    water_pct: Optional[float] = None
    built_pct: Optional[float] = None
    barren_pct: Optional[float] = None
    score: Optional[float] = None


class ConstructionVerdict(BaseModel):
    """Authoritative recommendation on whether the land is good for construction."""
    status: str = Field(..., description="safe | conditional | high_hazard | unsuitable")
    badge: str = Field(..., description="Display badge")
    badge_color: str = Field("#22c55e", description="Hex color")
    verdict_title: str
    summary: str
    recommendations: List[str] = Field(default_factory=list)


class AssessmentResult(BaseModel):
    """Top-level response returned by /api/score."""
    coordinates: Coordinates
    construction_score: float = Field(..., ge=0, le=100)
    habitability_score: float = Field(..., ge=0, le=100)
    overall_score: float = Field(..., ge=0, le=100)

    verdict: Optional[ConstructionVerdict] = None

    factors: Dict[str, FactorScore]

    terrain: Optional[TerrainDetail] = None
    climate: Optional[ClimateDetail] = None
    soil: Optional[SoilDetail] = None
    seismic: Optional[SeismicDetail] = None
    access: Optional[AccessDetail] = None
    land_cover: Optional[LandCoverDetail] = None

    warnings: List[str] = []
    hard_constraints: List[str] = []

    phase_sources: Dict[str, str] = Field(
        default_factory=lambda: {
            "terrain": "Open-Meteo Elevation API",
            "climate": "Open-Meteo Archive API",
            "soil": "ISRIC SoilGrids v2",
            "seismic": "USGS Earthquake Catalog",
            "access": "OpenStreetMap Overpass API",
        }
    )
