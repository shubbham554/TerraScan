"""Spatial lookup for optional HLS water observations produced offline."""
import logging
from contextlib import closing
from pathlib import Path
import sqlite3

LOG = logging.getLogger(__name__)
SCHEMA = """
CREATE TABLE IF NOT EXISTS patches (
    file TEXT PRIMARY KEY, west REAL, south REAL, east REAL, north REAL,
    acquired TEXT, water_pct REAL, valid_pixels INTEGER
);
CREATE INDEX IF NOT EXISTS patches_west ON patches(west);
"""


def index_patch(db, filename, bounds, acquired, water_pct, valid_pixels):
    with closing(sqlite3.connect(db)) as con, con:
        con.executescript(SCHEMA)
        con.execute("INSERT OR REPLACE INTO patches VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (filename, *bounds, acquired, float(water_pct), valid_pixels))


def load_hls_features(root: Path, lat: float, lon: float):
    """Use Fmask water where the requested pixel and patch both indicate water."""
    current = []
    try:
        import rasterio
        from rasterio.warp import transform
        from rasterio.windows import Window
    except ImportError:
        return None

    for stage in ("regional", "pilot"):
        folder = root / stage
        db = folder / "index.sqlite"
        if not db.is_file() or not (folder / "complete.json").is_file():
            continue
        try:
            with closing(sqlite3.connect(db.resolve().as_uri() + "?mode=ro", uri=True)) as con:
                rows = con.execute(
                    "SELECT file, acquired, water_pct, valid_pixels FROM patches "
                    "WHERE west <= ? AND east >= ? AND south <= ? AND north >= ?",
                    (lon, lon, lat, lat)).fetchall()
            current.extend((acquired, valid_pixels, fraction, folder / "patches" / file)
                           for file, acquired, fraction, valid_pixels in rows)
        except sqlite3.Error:
            LOG.warning("Could not read HLS index in %s", folder)
    for acquired, _, fraction, file in sorted(current, reverse=True):
        try:
            with rasterio.open(file) as src:
                x, y = transform("EPSG:4326", src.crs, [lon], [lat])
                row, col = src.index(x[0], y[0])
                if not (0 <= row < src.height and 0 <= col < src.width):
                    continue
                valid, water = src.read([7, 8], window=Window(col, row, 1, 1))[:, 0, 0]
                if not valid:
                    continue
                if water and fraction > 50:
                    return {"dominant_class": "water", "water_pct": fraction,
                            "source": "NASA HLS V2.0 Fmask", "acquired_utc": acquired}
                return None
        except (OSError, ValueError):
            LOG.warning("Could not read HLS patch %s", file.name)
    return None
