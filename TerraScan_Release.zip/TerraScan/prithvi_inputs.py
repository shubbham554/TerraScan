"""Read four aligned TerraScan HLS chips as Prithvi-EO-2.0-300M-TL inputs."""
from datetime import datetime

import numpy as np
import rasterio
import torch

from hls_dataset import NAMES, SIZE


def load_prithvi_sequence(paths):
    """Return inputs, QA mask and exact acquisition times from real GeoTIFFs."""
    frames = []
    grid = None
    for path in paths:
        with rasterio.open(path) as src:
            candidate = src.crs, src.transform, src.width, src.height
            if grid is None:
                grid = candidate
            if (grid != candidate or (src.width, src.height) != (SIZE, SIZE)
                    or src.descriptions != (*NAMES, "VALID_MASK", "FMASK_WATER")):
                raise ValueError("Expected aligned 224×224 TerraScan HLS chips")
            tags = src.tags()
            stamp = datetime.fromisoformat(tags["acquired_utc"])
            imagery = src.read([1, 2, 3, 4, 5, 6])
            valid = src.read(7).astype(bool)
            frames.append((stamp, imagery, valid))
    frames.sort(key=lambda frame: frame[0])
    if len(frames) != 4 or len({stamp.date() for stamp, _, _ in frames}) != 4:
        raise ValueError("Provide four real observations from distinct acquisition dates")
    timestamps, chips, masks = zip(*frames)
    return {
        "pixel_values": torch.from_numpy(np.stack(chips, axis=1))[None],
        "temporal_coords": torch.tensor(
            [[(stamp.year, stamp.timetuple().tm_yday) for stamp in timestamps]], dtype=torch.float32),
        "location_coords": torch.tensor(
            [[float(tags["center_lat"]), float(tags["center_lon"])]], dtype=torch.float32),
        "valid_mask": torch.from_numpy(np.stack(masks))[None],
        "acquired_utc": [stamp.isoformat() for stamp in timestamps],
    }
