"""Plan, download and preprocess genuine NASA HLS V2.0 imagery."""
import argparse
import hashlib
import json
import logging
import os
import shutil
import sqlite3
import time
from contextlib import ExitStack, closing
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlsplit

import earthaccess
import geopandas as gpd
import numpy as np
import rasterio as rio
from rasterio.features import geometry_mask
from rasterio.transform import array_bounds
from rasterio.vrt import WarpedVRT
from rasterio.warp import Resampling, transform, transform_bounds
from rasterio.windows import Window
from shapely.geometry import box

from app.hls_index import index_patch

LOG = logging.getLogger("hls")
SIZE = 224
BANDS = {
    "HLSL30": ("B02", "B03", "B04", "B05", "B06", "B07"),
    "HLSS30": ("B02", "B03", "B04", "B8A", "B11", "B12"),
}
NAMES = ("BLUE", "GREEN", "RED", "NIR_NARROW", "SWIR_1", "SWIR_2")
SCALE = np.float32(0.0001)
MEAN = np.array([1087, 1342, 1433, 2734, 1958, 1363], np.float32) * SCALE
STD = np.array([2248, 2179, 2178, 1850, 1242, 1049], np.float32) * SCALE
MASK_BITS = 0b00011110
WATER_BIT = 0b00100000
DEFAULT_OUTPUT = Path("data/hls")
GIB = 1024**3


def write_json(path, data):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    temp.replace(path)


def districts(path, name_field, pilot_district):
    frame = gpd.read_file(path)
    if frame.crs is None or name_field not in frame:
        raise ValueError("District polygons need a declared CRS and the specified name field")
    frame = frame[[name_field, frame.geometry.name]].rename(columns={name_field: "district"})
    if frame["district"].isna().any():
        raise ValueError("District names cannot be null")
    frame["district"] = frame["district"].astype(str).str.strip()
    frame = frame.dissolve(by="district", as_index=False).to_crs(4326)
    if (len(frame) != 75 or not frame["district"].all() or frame.geometry.is_empty.any()
            or not frame.is_valid.all() or not frame.geom_type.isin(["Polygon", "MultiPolygon"]).all()
            or not box(76, 23, 85, 32).covers(frame.geometry.union_all())):
        raise ValueError("Supply valid Uttar Pradesh polygons for exactly 75 named districts")
    if pilot_district:
        frame = frame[frame["district"].str.casefold() == pilot_district.casefold()]
        if len(frame) != 1:
            raise ValueError(f"District not found or ambiguous: {pilot_district}")
    return frame


def discover(frame, start, end, pilot):
    granules = []
    spatial = {"bounding_box": tuple(frame.total_bounds)}
    if pilot:
        point = frame.geometry.iloc[0].representative_point()
        spatial = {"point": (point.x, point.y)}
    for product, bands in BANDS.items():
        results = earthaccess.search_data(short_name=product, version="2.0",
                                          temporal=(start, end), **spatial)
        candidates = []
        for entry in results:
            umm = entry["umm"]
            name = umm["GranuleUR"]
            if not name.endswith(".v2.0") or not name.startswith("HLS." + product[3:] + "."):
                raise ValueError(f"Unexpected NASA granule identifier: {name}")
            required = set((*bands, "Fmask"))
            urls = {}
            for url in entry.data_links(access="external"):
                parsed = urlsplit(url)
                filename = parsed.path.rsplit("/", 1)[-1]
                band = filename.removeprefix(name + ".").removesuffix(".tif")
                if (parsed.scheme == "https" and parsed.hostname
                        and parsed.hostname.endswith((".earthdatacloud.nasa.gov", ".earthdata.nasa.gov"))
                        and filename == f"{name}.{band}.tif" and band in required):
                    urls[band] = url
            if set(urls) != required:
                raise RuntimeError(f"Missing required NASA HTTPS assets for {name}: {required - urls.keys()}")
            acquired = datetime.strptime(name.split(".")[3], "%Y%jT%H%M%S").isoformat() + "Z"
            cloud = umm.get("CloudCover")
            candidates.append({"id": name, "product": product, "date": acquired, "assets": urls,
                               "cloud_cover": cloud if cloud is not None else 100})
        candidates.sort(key=lambda item: (item["date"], item["id"]), reverse=True)
        if not candidates:
            raise RuntimeError(f"No {product} granules found in the requested interval")
        granules.extend([min(candidates, key=lambda item: float(item["cloud_cover"]))]
                        if pilot else candidates)
        LOG.info("Discovered %d %s granules, selected %d", len(candidates), product,
                 1 if pilot else len(candidates))
    return granules


def verified_tif(path):
    with rio.open(path) as source:
        if source.count != 1 or source.crs is None:
            raise ValueError(f"Invalid HLS raster: {path.name}")
        source.read(1, window=Window(0, 0, 1, 1))


def asset(session, url, target):
    if target.exists():
        try:
            verified_tif(target)
            return
        except (OSError, ValueError):
            target.unlink()
    partial = target.with_suffix(".part")
    for attempt in range(4):
        offset = partial.stat().st_size if partial.exists() else 0
        headers = {"Accept-Encoding": "identity"}
        if offset:
            headers["Range"] = f"bytes={offset}-"
        try:
            with session.get(url, headers=headers, timeout=(20, 120), stream=True) as response:
                if response.status_code in (401, 403):
                    raise PermissionError("NASA denied the request. Check Earthdata login and LP DAAC access.")
                if response.status_code == 416 and offset:
                    partial.unlink()
                    continue
                response.raise_for_status()
                append = response.status_code == 206
                if append:
                    content_range = response.headers.get("Content-Range", "")
                    if not content_range.startswith(f"bytes {offset}-"):
                        partial.unlink(missing_ok=True)
                        raise RuntimeError("Invalid range response")
                    total = int(content_range.rsplit("/", 1)[-1])
                else:
                    total = int(response.headers.get("Content-Length", 0))
                if not total:
                    raise RuntimeError("NASA did not supply the asset size")
                with partial.open("ab" if append else "wb") as stream:
                    for chunk in response.iter_content(1024 * 1024):
                        stream.write(chunk)
                if partial.stat().st_size != total:
                    raise RuntimeError("Incomplete HLS asset")
                try:
                    verified_tif(partial)
                except (OSError, ValueError):
                    partial.unlink(missing_ok=True)
                    raise
                partial.replace(target)
                return
        except PermissionError:
            raise
        except Exception as error:
            LOG.warning("%s attempt %d failed (%s)", target.name, attempt + 1, type(error).__name__)
            if attempt == 3:
                raise RuntimeError(f"Unable to download {target.name}") from None
            time.sleep(2**attempt)


def patches(item, paths, frame, run, min_clear):
    with ExitStack() as stack:
        qa = stack.enter_context(rio.open(paths["Fmask"]))
        if qa.crs is None or not np.allclose(qa.res, (30, 30)):
            raise ValueError("Expected an HLS 30 m reference grid")
        local = frame.to_crs(qa.crs)
        local = local[local.intersects(box(*qa.bounds))]
        if local.empty:
            return set()
        readers = []
        for band in BANDS[item["product"]]:
            src = stack.enter_context(rio.open(paths[band]))
            if (src.crs, src.transform, src.shape) != (qa.crs, qa.transform, qa.shape):
                src = stack.enter_context(WarpedVRT(
                    src, crs=qa.crs, transform=qa.transform, width=qa.width, height=qa.height,
                    src_nodata=-9999, nodata=-9999, resampling=Resampling.nearest))
            readers.append(src)
        covered = set()
        for row in range(0, qa.height, SIZE):
            for col in range(0, qa.width, SIZE):
                win = Window(col, row, min(SIZE, qa.width-col), min(SIZE, qa.height-row))
                affine = qa.window_transform(win)
                clip = box(*array_bounds(int(win.height), int(win.width), affine))
                subset = local.iloc[local.sindex.query(clip, predicate="intersects")]
                if subset.empty:
                    continue
                shape = int(win.height), int(win.width)
                district_masks = {
                    district: geometry_mask([geom], shape, affine, invert=True)
                    for district, geom in zip(subset["district"], subset.geometry)
                }
                inside = np.logical_or.reduce(list(district_masks.values()))
                fmask = qa.read(1, window=win)
                clear = inside & (fmask != 255) & ((fmask & MASK_BITS) == 0)
                dn = np.stack([src.read(1, window=win) for src in readers])
                clear &= (dn != -9999).all(axis=0)
                n_valid = int(clear.sum())
                if not n_valid or n_valid / max(1, inside.sum()) < min_clear:
                    continue
                valid_districts = sorted(name for name, mask in district_masks.items()
                                         if np.any(mask & clear))
                reflectance = dn.astype(np.float32) * SCALE
                normal = (reflectance - MEAN[:, None, None]) / STD[:, None, None]
                water = clear & ((fmask & WATER_BIT) != 0)
                red, nir = reflectance[2:4]
                denom = nir + red
                ndvi_ok = clear & (denom > 1e-6)
                ndvi = float(np.median(((nir-red)[ndvi_ok] / denom[ndvi_ok]))) if ndvi_ok.any() else None
                output = np.zeros((8, SIZE, SIZE), dtype=np.float32)
                output[:6, :shape[0], :shape[1]] = np.where(clear[None], normal, 0)
                output[6, :shape[0], :shape[1]] = clear
                output[7, :shape[0], :shape[1]] = water
                left, bottom, right, top = array_bounds(SIZE, SIZE, affine)
                lon, lat = transform(qa.crs, "EPSG:4326", [(left+right)/2], [(bottom+top)/2])
                bounds = transform_bounds(qa.crs, "EPSG:4326", left, bottom, right, top)
                filename = f'{item["id"]}_{row}_{col}.tif'
                target = run / "patches" / filename
                if not target.exists():
                    temp = target.with_suffix(".tmp")
                    with rio.open(temp, "w", driver="GTiff", width=SIZE, height=SIZE,
                                  count=8, dtype="float32", crs=qa.crs, transform=affine,
                                  compress="deflate", predictor=3) as dst:
                        dst.write(output)
                        dst.descriptions = (*NAMES, "VALID_MASK", "FMASK_WATER")
                        dst.update_tags(granule=item["id"], product=item["product"],
                                        acquired_utc=item["date"], districts=json.dumps(valid_districts),
                                        center_lat=str(lat[0]), center_lon=str(lon[0]),
                                        valid_fraction=str(n_valid / max(1, inside.sum())),
                                        water_pct=str(100 * water.sum() / n_valid),
                                        median_ndvi="" if ndvi is None else str(ndvi))
                    temp.replace(target)
                index_patch(run / "index.sqlite", filename, bounds, item["date"],
                            100 * water.sum() / n_valid, n_valid)
                covered.update(valid_districts)
        return covered


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=["pilot", "regional"])
    parser.add_argument("--boundaries", type=Path, required=True)
    parser.add_argument("--name-field", required=True)
    parser.add_argument("--start", type=date.fromisoformat, required=True)
    parser.add_argument("--end", type=date.fromisoformat, required=True)
    parser.add_argument("--pilot-district", default="Lucknow")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--min-clear", type=float, default=0.7)
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--interactive", action="store_true")
    args = parser.parse_args()
    if args.start > args.end or not 0 < args.min_clear <= 1:
        parser.error("Use increasing dates and a clear threshold in (0, 1]")
    pilot = args.stage == "pilot"
    frame = districts(args.boundaries, args.name_field, args.pilot_district if pilot else None)
    args.output.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(args.output / ".download-lock.sqlite", timeout=1)) as lock:
        try:
            lock.execute("BEGIN IMMEDIATE")
        except sqlite3.OperationalError as error:
            raise RuntimeError(f"Cannot lock the HLS output directory: {error}") from None
        execute(args, frame, pilot)


def execute(args, frame, pilot):
    boundary_digest = hashlib.sha256(
        frame.sort_values("district").to_json().encode("utf-8")).hexdigest()
    run = args.output / args.stage
    run.mkdir(parents=True, exist_ok=True)
    plan_file = run / "plan.json"
    plan_key = {"start": str(args.start), "end": str(args.end), "boundaries": boundary_digest,
                "min_clear": args.min_clear, "stage": args.stage}
    if plan_file.exists():
        plan = json.loads(plan_file.read_text(encoding="utf-8"))
        if plan["settings"] != plan_key:
            raise ValueError("This output already has a different plan. Use another --output directory.")
        granules = plan["granules"]
    else:
        granules = discover(frame, f"{args.start}T00:00:00Z", f"{args.end}T23:59:59Z", pilot)
        write_json(plan_file, {"settings": plan_key, "granules": granules})
    cache = args.output / "cache"
    remaining = [item for item in granules
                 if not (run / "granules" / (item["id"] + ".json")).exists()]
    missing = sum(not (cache / item["id"] / f'{item["id"]}.{band}.tif').exists()
                  for item in remaining for band in item["assets"])
    # A 3,660-square 16-bit input plus overhead per asset, and a full padded tile of patches.
    planned_bytes = missing * 32_000_000 + len(remaining) * 17**2 * SIZE**2 * 32
    reserve = int(planned_bytes * 1.15)
    free = shutil.disk_usage(run).free
    LOG.info("%d granules, %d uncached assets, estimated %.2f GiB incl. headroom, %.2f GiB free",
             len(granules), missing, reserve/GIB, free/GIB)
    if args.plan:
        return
    if reserve > free:
        raise RuntimeError("Insufficient free disk space for the conservative estimate")
    if not pilot and not (args.output / "pilot" / "complete.json").is_file():
        raise RuntimeError("Complete a real pilot for both sensors before running regional downloads")
    strategy = "netrc"
    if args.interactive:
        strategy = "interactive"
    elif os.getenv("EARTHDATA_TOKEN") or all(os.getenv(key) for key in
                                            ("EARTHDATA_USERNAME", "EARTHDATA_PASSWORD")):
        strategy = "environment"
    try:
        auth = earthaccess.login(strategy=strategy, persist=False)
    except Exception as error:
        raise RuntimeError(
            f"Earthdata sign-in failed ({type(error).__name__}). Check connectivity and "
            "authenticate with a configured credential or --interactive in a private terminal."
        ) from None
    if not auth.authenticated:
        raise RuntimeError("Earthdata login is required. Run with --interactive in a private terminal.")
    session = earthaccess.get_requests_https_session()
    (run / "patches").mkdir(exist_ok=True)
    (run / "granules").mkdir(exist_ok=True)
    boundaries = run / "districts.geojson"
    if not boundaries.exists():
        write_json(boundaries, json.loads(frame.to_json()))
    coverage = {product: set() for product in BANDS}
    failures = []
    with session:
        for index, item in enumerate(granules, 1):
            ident = item["id"]
            LOG.info("[%d/%d] %s", index, len(granules), ident)
            try:
                done = run / "granules" / f"{ident}.json"
                if done.exists():
                    covered = json.loads(done.read_text(encoding="utf-8"))
                else:
                    folder = cache / ident
                    folder.mkdir(parents=True, exist_ok=True)
                    paths = {}
                    for band, url in item["assets"].items():
                        paths[band] = folder / f"{ident}.{band}.tif"
                        asset(session, url, paths[band])
                    covered = sorted(patches(item, paths, frame, run, args.min_clear))
                    write_json(done, covered)
                coverage[item["product"]].update(covered)
            except PermissionError:
                raise
            except Exception as error:
                LOG.error("%s failed: %s", ident, error)
                failures.append(ident)
    uncovered = {product: sorted(set(frame["district"]) - covered)
                 for product, covered in coverage.items()}
    report = {"granules": len(granules), "uncovered": uncovered, "failed_granules": failures}
    write_json(run / "coverage.json", report)
    if failures or any(uncovered.values()):
        raise RuntimeError(f"Coverage incomplete. See {run / 'coverage.json'}")
    write_json(run / "complete.json", report)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    try:
        main()
    except (ValueError, RuntimeError, OSError) as exc:
        raise SystemExit(f"Error: {exc}") from None
