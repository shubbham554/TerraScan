# TerraScan deployment

The release targets a public Linux OCI container behind an HTTPS reverse proxy. It serves the frontend and API from one origin. The runtime needs network access to the upstream geospatial providers used by the existing assessment endpoints.

```sh
docker build -t terrascan:1.1 .
docker run --rm -p 127.0.0.1:8000:8000 terrascan:1.1
curl -fsS http://127.0.0.1:8000/api/health
```

Publish the image on a container host with ingress on port 8000 and use `GET /api/health` for the liveness check. Configure HTTPS and request limits at the ingress. The container runs as an unprivileged user. The health check verifies the app process and does not depend on upstream service availability.

## Optional satellite water observation

Mount a read-only directory at `/observations` and set `TERRASCAN_FLOOD_OBSERVATION_DIR=/observations`. It must contain:

- `water.tif`, a georeferenced binary raster with land as 0, water as 1 and a declared nodata value.
- `observation.json`, with `source` and `acquired_on` fields. Use the actual satellite acquisition date in ISO form.

`GET /api/flood-observation?lat=...&lon=...` serves the point classification independently from historical flood risk. Areas outside the mapped tile and masked pixels return distinct coverage statuses. The app works without an installed observation. The separate HLS batch pipeline is covered in the README.

## Research status

The Prithvi EO 1.0 flood checkpoint ran on Sen1Floods11 test chip `India_900498_S2Hand.tif`. Of 262,144 valid source pixels, 133,751 were classified as water or flood. Comparison against the hand label yielded 88.12% water-class IoU and 93.69% F1 over 261,992 labelled pixels after nearest-neighbor alignment. See the [pilot notebook](https://colab.research.google.com/drive/10b1Val6mbow4xmIdCRQMHdZrl_EAULMB).

This is a single-chip result. An independent Uttar Pradesh event validation and the regional HLS download remain pending. The service treats predicted water as a dated observation, and the original assessment and risk scores continue to use their existing inputs. The assessment is a research prototype and has no site-specific engineering validation.
