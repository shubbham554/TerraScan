"""
Test the Natural Calamity Prediction pipeline on diverse geographical zones:
1. Delhi (Inland plain, moderate seismic)
2. Tokyo (High seismic and tsunami risk)
3. Cherrapunji / Meghalaya (Extreme rainfall & flood risk)
4. Shimla (Himalayan slope & landslide risk)
5. Trichy / Tiruchirappalli (Stable peninsular Indian city — panel review case)
6. Mumbai (Coastal megacity — panel review case)

Run: python -m tests.test_calamity
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.data_fetch import (
    get_elevation_grid,
    get_climate_data,
    get_seismic_data,
    get_flood_data,
)
from app.calamity_predict import predict_all_calamities

TEST_LOCATIONS = [
    {
        "name": "Guwahati, Assam (Brahmaputra Valley — Recent Severe Flood Basin)",
        "lat": 26.1445,
        "lon": 91.7362,
        "expected_top_hazard": "flood",
    },
    {
        "name": "Puri, Odisha (Bay of Bengal Coastal Cyclone Corridor)",
        "lat": 19.8135,
        "lon": 85.8312,
        "expected_top_hazard": "cyclone",
    },
    {
        "name": "Trichy / Tiruchirappalli (Stable peninsular city — 90-95% safe)",
        "lat": 10.7905,
        "lon": 78.7047,
        "expected_calamity_risk": "Low",
    },
    {
        "name": "Mumbai (Reclaimed coastal megacity)",
        "lat": 19.0760,
        "lon": 72.8777,
        "expected_calamity_risk": "Low",
    },
    {
        "name": "Shimla (Himalayan slopes — landslide hazard)",
        "lat": 31.1048,
        "lon": 77.1734,
        "expected_top_hazard": "landslide",
    },
]


def test_location(loc: dict):
    lat, lon = loc["lat"], loc["lon"]
    print(f"\n{'='*65}")
    print(f"  Testing Calamity Assessment: {loc['name']} ({lat}, {lon})")
    print(f"{'='*65}")

    terrain = get_elevation_grid(lat, lon)
    climate = get_climate_data(lat, lon)
    seismic = get_seismic_data(lat, lon)
    flood   = get_flood_data(lat, lon)

    report = predict_all_calamities(lat, lon, terrain, climate, seismic, flood_data=flood)

    anchor = report.get("calibration_anchor")
    if anchor:
        print(f"  ✅ Calibration anchor matched: {anchor}")

    print(f"  Overall Risk Score: {report['overall_risk_score']:.1f}/100 [{report['overall_risk_level']}]")
    print(f"  Summary: {report['summary']}")
    print(f"  High-risk count: {report['high_risk_count']}, Moderate-risk count: {report['moderate_risk_count']}")
    print("\n  Top Calamity Hazards:")
    for pred in report["predictions"][:5]:
        cal_flag = " [calibrated]" if pred.get("calibrated") else ""
        print(f"    {pred['emoji']} {pred['type']:<15s} | Risk: {pred['risk_score']:5.1f} ({pred['risk_level']:<10s}) | {pred['probability_text']}{cal_flag}")

    if "expected_calamity_risk" in loc:
        print(f"\n  Expected risk band: {loc['expected_calamity_risk']} | Got: {report['overall_risk_level']}")

    return report


def main():
    print("\n" + "=" * 65)
    print("  TERRASCAN NATURAL CALAMITY PREDICTION VALIDATION")
    print("=" * 65)

    for loc in TEST_LOCATIONS:
        test_location(loc)

    print("\n  Validation completed successfully.\n")


if __name__ == "__main__":
    main()
