"""
Phase 5 – Test the scoring pipeline on 3 known locations.
Run: python -m tests.test_known_places
"""

import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.data_fetch import (
    get_elevation_grid, get_climate_data,
    get_soil_data, get_seismic_data, get_infrastructure_data,
)
from app.scoring import build_assessment

# ── Test locations ─────────────────────────────────────────────────
PLACES = [
    {
        "name": "Delhi (flat plain)",
        "lat": 28.6139,
        "lon": 77.2090,
        "expect": "High construction score, moderate habitability (hot summers)",
    },
    {
        "name": "Shimla (mountain)",
        "lat": 31.1048,
        "lon": 77.1734,
        "expect": "Lower construction (slope), good habitability (cool climate)",
    },
    {
        "name": "Mumbai coast (flood-prone)",
        "lat": 19.0760,
        "lon": 72.8777,
        "expect": "Moderate construction (flood risk), moderate habitability (humid)",
    },
]


def test_place(place: dict):
    lat, lon = place["lat"], place["lon"]
    name = place["name"]
    print(f"\n{'='*60}")
    print(f"  Testing: {name}")
    print(f"  Coordinates: ({lat}, {lon})")
    print(f"  Expected: {place['expect']}")
    print(f"{'='*60}")

    print("  Fetching terrain...", end=" ", flush=True)
    terrain = get_elevation_grid(lat, lon)
    print("OK" if "error" not in terrain else f"WARN: {terrain.get('error', '')[:60]}")

    print("  Fetching climate...", end=" ", flush=True)
    climate = get_climate_data(lat, lon)
    print("OK" if "error" not in climate else f"WARN: {climate.get('error', '')[:60]}")

    print("  Fetching soil...", end=" ", flush=True)
    soil = get_soil_data(lat, lon)
    print("OK" if "error" not in soil else f"WARN: {soil.get('error', '')[:60]}")

    print("  Fetching seismic...", end=" ", flush=True)
    seismic = get_seismic_data(lat, lon)
    print("OK" if "error" not in seismic else f"WARN: {seismic.get('error', '')[:60]}")

    print("  Fetching infrastructure...", end=" ", flush=True)
    infra = get_infrastructure_data(lat, lon)
    print("OK")

    result = build_assessment(lat, lon, terrain, climate, soil, seismic, infra)

    print(f"\n  -----------------------------------------")
    print(f"  |  Construction Score:  {result.construction_score:5.1f} / 100       |")
    print(f"  |  Habitability Score:  {result.habitability_score:5.1f} / 100       |")
    print(f"  |  Overall Score:       {result.overall_score:5.1f} / 100       |")
    print(f"  -----------------------------------------")

    print("\n  Factor breakdown:")
    for key, factor in result.factors.items():
        val_str = f"{factor.value}" if factor.value is not None else "N/A"
        print(f"    {key:12s} -> {factor.score:5.1f}  [{factor.rating:10s}]  ({val_str} {factor.unit})")

    if result.warnings:
        print("\n  ! Warnings:")
        for w in result.warnings:
            print(f"    - {w}")

    if result.hard_constraints:
        print("\n  X Hard constraints:")
        for c in result.hard_constraints:
            print(f"    - {c}")

    return result


def main():
    print("\n" + "=" * 60)
    print("  LAND SUITABILITY ASSESSMENT - VALIDATION TEST")
    print("=" * 60)

    results = []
    for place in PLACES:
        r = test_place(place)
        results.append({"name": place["name"], "construction": r.construction_score,
                         "habitability": r.habitability_score, "overall": r.overall_score})

    print("\n\n" + "=" * 60)
    print("  SUMMARY")
    print("=" * 60)
    print(f"  {'Location':<30s} {'Construction':>12s} {'Habitability':>12s} {'Overall':>10s}")
    print(f"  {'-'*30} {'-'*12} {'-'*12} {'-'*10}")
    for r in results:
        print(f"  {r['name']:<30s} {r['construction']:>10.1f}% {r['habitability']:>10.1f}% {r['overall']:>8.1f}%")

    print("\n  OK If Delhi is high, Shimla is lower construction, Mumbai is moderate -> pipeline works!")
    print()


if __name__ == "__main__":
    main()
