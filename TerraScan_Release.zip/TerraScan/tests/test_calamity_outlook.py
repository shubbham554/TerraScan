"""Tests for the point-specific calamity screening verdict."""

import unittest
from unittest.mock import patch

from app.calamity_predict import predict_all_calamities


class CalamityOutlookTests(unittest.TestCase):
    def predict(self, terrain=None, climate=None, seismic=None):
        with patch("app.calamity_predict._estimate_coast_distance_km", return_value=200):
            return predict_all_calamities(
                28.6,
                77.2,
                terrain or {},
                climate or {},
                seismic or {},
            )

    def test_reports_elevated_outlook_for_high_risk_hazard(self):
        report = self.predict(
            seismic={"earthquake_count": 80, "max_magnitude": 7.5, "nearest_km": 10}
        )

        self.assertEqual(report["pinpoint_outlook"]["status"], "elevated")
        self.assertEqual(report["pinpoint_outlook"]["top_hazard"]["type"], "earthquake")

    def test_distinguishes_no_high_risk_from_no_risk(self):
        report = self.predict()

        self.assertEqual(report["pinpoint_outlook"]["status"], "no_high_risk_detected")
        self.assertIn("not a guarantee of safety", report["pinpoint_outlook"]["message"])


if __name__ == "__main__":
    unittest.main()